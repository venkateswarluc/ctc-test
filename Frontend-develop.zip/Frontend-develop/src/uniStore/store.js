import createStore from 'unistore';

const auth_init = { fireUser: false, isLoaded: false };
const loader_init = { opened: false, size: 32 };
const confirm_init = { opened: false, title: "Confirm", message: "Are you sure?", yes: "Proceed", no: "Cancel", onDone: () => { } };
const snackbar_init = { opened: false, message: '', color: 'black', timeout: 4000 };
const dialog_init = { opened: false, title: "", warning: "", onDone: () => {}, loading: false}
const documentStatus = { documents: 0}
const role = { role: '' }
const user = {};
const DOCUMENT_UPLOAD = "DOCUMENT_UPLOAD";
const ROLE = 'ROLE';
export const getInitState = (name) => {
    switch (name) {
        case "auth": {
            return auth_init;
        }
        case "confirm": {
            return confirm_init;
        }
        case "loader": {
            return loader_init;
        }
        case "snackbar": {
            return snackbar_init;
        }
        case "dialog": {
            return dialog_init;
        }
        case "DOCUMENT_UPLOAD": {
            return documentStatus;
        }
        case ROLE: {
            return role;
        }
        case "user": {
            return user;
        }
    }

    throw new Error('failed-precondition', 'No name');
}

const rootStore = {
    auth: getInitState("auth"),
    confirm: getInitState("confirm"),
    loader: getInitState("loader"),
    snackbar: getInitState("snackbar"),
    dialog: getInitState("dialog"),
    theme: 'light',
    documentStatus: getInitState(DOCUMENT_UPLOAD),
    role: getInitState(ROLE),
    user: getInitState('user')
}


export default createStore(rootStore);