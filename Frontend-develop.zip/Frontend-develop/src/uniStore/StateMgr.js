//-> Reduxies
import store, {
    getInitState
} from 'appRoot/uniStore/store';


//store.subscribe(state => console.log(state));

export function setAuth(payload) {
    const state = store.getState()["auth"];
    store.setState({ auth: { ...state, isLoaded: true, ...payload } });    
}

export function setTheme(theme = 'light') {
    store.setState({ theme });
}


/*COMP FUNCIONS */
export function openComp({ compName, payload }) {
    const state = store.getState()[compName];
    store.setState({ [compName]: { ...state, ...payload, opened: true } });
}

export function closeComp({ compName }) {
    const state = store.getState()[compName];
    store.setState({ [compName]: { ...state, opened: false } });
}

export function resetComp({ compName }) {
    const state = store.getState()[compName];  
    store.setState({ [compName]: {...state, opened: false, loading: false} })
}

export function setDocumentUpload(payload) {
    const state = store.getState()['documentStatus'];  
    store.setState({ documentStatus: { ...state, documents: payload}});
}
export function setRole(payload) {
    const state = store.getState()['role'];  
    store.setState({ role: { ...state, role: payload}});
}
export function setUser(payload) {
    store.setState({ user: { ...payload}});
}