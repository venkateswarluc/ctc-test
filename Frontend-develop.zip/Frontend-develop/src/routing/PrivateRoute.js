import React, { useEffect, useState } from 'react';
import { connect } from 'unistore/react';
import { GetAuth, GetDocumentSubmit } from "../libs/apiProvider/apiProvider";
import { Route, Redirect, useHistory } from 'react-router-dom';
import AiCircularLoader from 'appRoot/components/AiCircularLoader';
import jwt_decode from "jwt-decode";
const PrivateRoute = ({
    component: Component,
    fireUser,
    isLoaded,
    ...rest
}) => {
    const [scope, setScope] = useState(null);
    const history = useHistory();
    useEffect(() => {
        let timer;
        if (fireUser) {
            const decodeData = jwt_decode(fireUser);
            if('scope' in decodeData) {
                setScope(decodeData.scope);
            }
        }else {
            timer = setTimeout(() => {
                if(!fireUser) {
                    clearTimeout(timer);
                    history.push('/login');
                }
            }, 1000);
        }
        return () => clearTimeout(timer);
    }, [fireUser]);
   if(scope) {
    return <Route {...rest} render={props => !isLoaded ? (<AiCircularLoader opened={true} />) : (fireUser && scope === 'merchant') ? (<Component {...props} />) :  (<Redirect to="/" />)} />;
   }
   return <AiCircularLoader opened={true} />
};


const mapStateToProps = store => {
    return {
        isLoaded: store.auth.isLoaded,
        fireUser: store.auth.fireUser,
        documentStatus: store.documentStatus.documents,
    }
};
export default connect(mapStateToProps)(PrivateRoute);