import React, { Fragment, useEffect, useState } from 'react';

//---> Startup Comps
import AiConfirm from "appRoot/components/AiConfirm";
import AiSnackbar from "appRoot/components/AiSnackbar";
import { Route, Switch } from 'react-router';

import ProfileView from "appRoot/views/profile";
import Login from "appRoot/views/loginRegister/Login";
import Register from "appRoot/views/loginRegister/Register";
import ForgotPassword from "appRoot/views/loginRegister/ForgotPassword";
import ResetPassword from "appRoot/views/loginRegister/ResetPassword";
import DocumentUpload from "appRoot/views/uploadDocument";
import RegisterMerchant from "../views/admin/merchantRegistration/MerchantRegister";
import ErrorView from "appRoot/views/error";

import { connect } from 'unistore/react';
import PrivateRoute from './PrivateRoute';
import AdminRoute from './AdminRoute';
import { resetComp } from "appRoot/uniStore/StateMgr";
import MerchantList from '../views/admin/merchantList/MerchantList';
import MerchantDetails from '../views/admin/merchantDetails/MerchantDetails';
import AiModal from '../components/AiModal';
import ProfileDetails from '../views/profile/ProfileDetails';
import EditProfile from '../views/profile/EditProfile';
import Accounts from '../views/accounts/Accounts';
import UsersList from '../views/admin/users/usersList/UsersList';
import MerchantTransactions from '../views/merchantTransactions/MerchantTransactions';
import Dashboard from '../views/dashboard';
import EditMerchant from '../views/admin/editMerchant/EditMerchant';
import Transactions from '../views/admin/merchantTransactions/Transactions';
function Routes({ confirm, snackbar, documentStatus, dialog, fireUser }) {
    
    return (
        <Fragment>
            <AiConfirm {...confirm} />
            <AiSnackbar onClose={() => { resetComp({ compName: "snackbar" }) }}  {...snackbar} />
            <AiModal {...dialog} />
            <Switch>
                <Route exact path="/" component={Dashboard} />
                <Route exact path="/register" component={Register} />
                <Route exact path="/login" component={Login} />
                <Route exact path="/resetPassword" component={ResetPassword} />
                <Route exact path="/profile" component={ProfileView} />
                <Route exact path="/forgot-password" component={ForgotPassword} />
                
                <PrivateRoute exact path="/uploadDocument" component={DocumentUpload} />
                <PrivateRoute exact path="/profileDetails" component={ProfileDetails} />
                <PrivateRoute exact path="/editProfile" component={EditProfile} />
                <PrivateRoute exact path="/merchantTransactions" component={MerchantTransactions} />
                <PrivateRoute exact path="/accounts" component={Accounts} />

                <AdminRoute exact path="/registerMerchant" component={RegisterMerchant} />
                <AdminRoute exact path="/merchantList" component={MerchantList} />
                <AdminRoute path="/merchantDetails" component={MerchantDetails} />
                <AdminRoute path="/usersList" component={UsersList} />
                <AdminRoute path="/editMerchant" component={EditMerchant} />
                <AdminRoute path="/transactions" component={Transactions} />
                <Route path="*">
                    <ErrorView />
                </Route>
            </Switch>
        </Fragment>
    );
}

export default connect(store => {
    return {
        confirm: store.confirm,
        snackbar: store.snackbar,
        dialog: store.dialog,
        documentStatus: store.documentStatus.documents,
        fireUser: store.auth.fireUser
    }
})(Routes);