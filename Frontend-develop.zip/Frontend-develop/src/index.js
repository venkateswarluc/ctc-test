import "regenerator-runtime/runtime";


import React from 'react';
import { render } from 'react-dom';
import { Provider } from "unistore/react";

//=+++=>AIUI
import store from "appRoot/uniStore/store";
import App from "appRoot/app.js";

render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById("root")
)