import React, { Fragment, useEffect } from "react";
import { connect } from "unistore/react";


//App 
import { GetAuth, GetDocumentSubmit } from "../libs/sessionStorage/storageApis";
import { setAuth } from "appRoot/uniStore/StateMgr";
import DocumentUpload from "appRoot/views/uploadDocument"

const PageTag = ({ fireUser, checkAuth = true, children, documentStatus, ...props }) => {

    useEffect(() => {
        let isAuthenticated = GetAuth();
        if (!isAuthenticated) {
            setAuth({ fireUser: false });
        }
        window.scrollTo(0, 0);
    }, []);
    return (
        <Fragment>
            {
                <div {...props}>
                    {children}
                </div>
            }
            <div style={{height: 50}}></div> 
        </Fragment>
    )
};

export default connect(store => ({
    fireUser: store.auth.fireUser,
    documentStatus: store.documentStatus.documents
}))(PageTag);