import React, { useEffect, useState } from "react";
import { Link, useHistory, useLocation } from "react-router-dom";
import { connect } from "unistore/react";

//MAT-UI
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import useScrollTrigger from '@material-ui/core/useScrollTrigger';
import Slide from '@material-ui/core/Slide';
import SwipeableDrawer from '@material-ui/core/SwipeableDrawer';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import Icon from '@material-ui/core/Icon';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Tooltip from '@material-ui/core/Tooltip';
import jwt_decode from "jwt-decode";
import { setTheme } from "appRoot/uniStore/StateMgr";
import { Logout } from "../libs/apiProvider/apiProvider";
import { ListSubheader, MenuItem, MenuList } from "@material-ui/core";
import AccountBalanceIcon from '@material-ui/icons/AccountBalance';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import Logo from '../assets/logo.png';
import AVATAR from '../assets/avatar.jpg'
import { BOX_SHADOW, colorPalette } from "../libs/styleProvider";
import Menu from '@material-ui/core/Menu';
import MenuContainer from '../components/Menu/Menu';
import HomeIcon from '@material-ui/icons/Home';

function HideOnScroll(props) {
  const { children } = props;

  const trigger = useScrollTrigger();

  return (
    <Slide appear={false} direction="down" in={!trigger}>
      {children}
    </Slide>
  );
}



const BarTag = ({
  title = false,
  drawer = true,
  back = false,
  todash = false,
  profile = true,
  dMode = true,
  Menu = false,
  color = "inherit",
  fireUser,
  user
}) => {
  let history = useHistory();
  let location = useLocation();

  const [opened, setOpened] = useState(false);
  const [scope, setScope] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const anchorRef = React.useRef(null);
  useEffect(() => {
    if (fireUser) {
      const decodedToken = jwt_decode(fireUser);
      if ('scope' in decodedToken) {
        setScope(decodedToken.scope);
      }

    }
  }, []);

  const toggleDrawer = (open = true) => (event) => {
    if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setOpened(open);
  };


  const goBack = () => { history.length > 1 ? history.goBack() : history.push('/') };
  const handleMenu = () => {
    const toggleMenu = menuOpen;
    setMenuOpen(!toggleMenu);

    
  };

  const renderProfilePic = (avatar) => <img style={{ width: 35, height: 35, borderRadius: 100 }} src={avatar} />

  const renderListItem = (label, link, IconName) => {
    const processedLink = link.includes('?') ? link.split('?')[0] : link;
    return <ListItem key={`drawerLeft_list_${label}`} button aria-label={label} to={link} component={Link} selected={location.pathname === processedLink ? true : false}>
      <ListItemIcon>{typeof IconName === 'string' ? <Icon style={{ color: location.pathname === processedLink && colorPalette.primary }}>{IconName}</Icon> : <IconName style={{ color: location.pathname === processedLink && colorPalette.primary }} />}</ListItemIcon>
      <ListItemText primary={label} />
    </ListItem>
  };
  const renderToolbarItem = (title, position, label, avatar, func = () => { }) => <Tooltip title={title} edge={position}>
    <IconButton ref={anchorRef} onClick={func} edge={position} color="inherit" aria-label={label}>

      {typeof avatar === 'string' ? <Icon>{avatar}</Icon> : (Object.entries(avatar).length === 0 || avatar && avatar.profile_pic === null) ? renderProfilePic(AVATAR) : renderProfilePic(avatar.profile_pic)}
    </IconButton>
  </Tooltip>;

  const menuItem = (link, icon, text, func = false) => func ?  <MenuItem onClick={func} style={{color: colorPalette.danger}}><Icon style={{fontSize: 20, marginRight: 10}}>{icon}</Icon>{text}</MenuItem>: <MenuItem component={Link} to={link} ><Icon style={{fontSize: 20, marginRight: 10}}>{icon}</Icon>{text}</MenuItem>
  return (
    <React.Fragment>
      <HideOnScroll>
        <AppBar elevation={0} color={color} style={{ boxShadow: BOX_SHADOW }}>
             <MenuContainer opened={menuOpen} handleClose={handleMenu} anchorRef={anchorRef}>
            {profile && scope === 'merchant' && menuItem('/profileDetails', 'person', 'View Profile')}
            {profile && scope === 'merchant' && menuItem('/editProfile', 'edit', 'Edit Profile')}
            {menuItem('', 'exit_to_app', 'Log Out', () => { Logout(); history.push('/login') })}
          </MenuContainer>
          <Toolbar>
            {
              drawer && renderToolbarItem("Drawer", "start", "Drawer Menu", "menu", toggleDrawer(true))
            }
            {
              back && renderToolbarItem("Back", "start", "Back", "arrow_back", goBack)
            }
            {
              todash && renderToolbarItem("Dashboard", "start", "Dashboard", "dashboard")
            }
            {
              title && <Typography variant="h6" className="w3-caps" style={{ marginLeft: 8 }}>{title}</Typography>
            }
            <div style={{ flexGrow: 1 }} />
            {
              Menu && <Menu />
            }

            {
             profile && renderToolbarItem("Profile", "end", "Profile", user, handleMenu)
            }

          </Toolbar>
        </AppBar>
      </HideOnScroll>
      <Toolbar />

      <SwipeableDrawer anchor="left" open={opened} onClose={toggleDrawer(false)} onOpen={toggleDrawer(true)}>
        <div role="presentation" onClick={toggleDrawer(false)} onKeyDown={toggleDrawer(false)} style={{ width: 250, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <List>
            <ListSubheader disableSticky style={{ padding: 25, margin: 10 }}>
              <img src={Logo} style={{ width: '100%' }} />
            </ListSubheader>
            {renderListItem('DASHBOARD', '/', HomeIcon)}
            {scope === 'admin' && renderListItem('MERCHANTS', '/merchantList', 'storefront')}
            {scope === 'admin' && renderListItem('USERS', '/usersList', 'people')}
            {scope === 'merchant' && renderListItem('ACCOUNTS', '/accounts', AccountBalanceIcon)}
            {scope === 'merchant' && renderListItem('TRANSACTIONS', '/merchantTransactions?transaction_source=ALL&transaction_type=ALL', AccountBalanceWalletIcon)}

          </List>

          <List>
            <ListItem key={0} button aria-label={'LOGOUT'} onClick={() => { Logout(); history.push('/login') }}>
              <ListItemIcon><Icon>{'exit_to_app'}</Icon></ListItemIcon>
              <ListItemText primary={'LOG OUT'} />
            </ListItem>
          </List>
        </div>
      </SwipeableDrawer>

    </React.Fragment >
  )
}

export default connect(store => ({
  appliedTheme: store.theme,
  fireUser: store.auth.fireUser,
  user: store.user
}))(BarTag);