import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { connect } from "unistore/react";


//MAT-UI
import CssBaseline from '@material-ui/core/CssBaseline';
import { createMuiTheme, ThemeProvider } from '@material-ui/core/styles';
import teal from '@material-ui/core/colors/teal';
import cyan from '@material-ui/core/colors/cyan';
import pink from '@material-ui/core/colors/pink';
import red from '@material-ui/core/colors/red';

//AIUI
import { GetAuth } from "./libs/sessionStorage/storageApis";
import {  setAuth } from "appRoot/uniStore/StateMgr";


import Routes from "appRoot/routing/routes";
import { getProfile } from "./libs/apiProvider/apiProvider";
import { setUser } from "./uniStore/StateMgr";
import jwtDecode from "jwt-decode";


const App = ({ confirm, snackbar, isLoaded, appliedTheme }) => {

 
  useEffect(() => {
    let fireUser = GetAuth();
    if (fireUser) {
      setAuth({ fireUser });
      const decoded = jwtDecode(fireUser);
      if(decoded.scope === 'merchant') {
        getProfile().then(res => {
          setUser(res);
        });
      }
    } else {
      setAuth({ fireUser: false });
    }
  }, []);


  const theme = createMuiTheme({
  });
 
  return (
    <ThemeProvider theme={theme}>
       <CssBaseline />  
       <Router>
        <Switch>
          <Route component={Routes} />
        </Switch>  
      </Router> 
    </ThemeProvider>
  )
}

export default connect(store => ({
  confirm: store.confirm,
  snackbar: store.snackbar,
  appliedTheme: store.theme,
  documentStatus: store.documentStatus.documents
}))(App);