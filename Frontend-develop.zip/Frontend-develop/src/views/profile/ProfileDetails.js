import { Button, Container, Fab, Grid, Icon, IconButton, List, ListItem, ListItemIcon, ListItemSecondaryAction, ListSubheader, makeStyles, Paper, Tooltip, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { getProfile, updateMerchantProfile, updateProfilePic, uploadDocument } from '../../libs/apiProvider/apiProvider';
import BarTag from '../../tags/BarTag';
import PageTag from '../../tags/PageTag';
import FolderIcon from '@material-ui/icons/Folder';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import UpdateIcon from '@material-ui/icons/Update';
import CircularLoader from '../../components/AiCircularLoader';
import { openComp, setUser } from '../../uniStore/StateMgr';
import { BORDER_RADIUS, BOX_SHADOW, colorPalette } from '../../libs/styleProvider';
import AVATAR from '../../assets/avatar.jpg';
import { Link } from 'react-router-dom';
import { documentTypes } from '../../libs/helper';
const useStyles = makeStyles((theme) => ({
    paper: {
        padding: 15,
        paddingTop: 20,
        wordWrap: "break-word",
        borderRadius: BORDER_RADIUS,
        boxShadow: BOX_SHADOW,
        marginBottom: 20,
        marginTop: 140
    },
    approveButton: {
        "&:hover": {
            backgroundColor: 'transparent'
        },
        cursor: 'default'
    },
    list: {
        wordWrap: 'break-word'
    },
    listItem: {
        paddingBlock: 0,
        wordBreak: 'break-all'
    },
    docListHeading: {
        fontWeight: '700',
        width: '100%',
        [theme.breakpoints.down('xs')]: {
            fontSize: 14,
            marginLeft: -10,
            width: '50%'
        }
    },
    downloadIcon: {
        color: colorPalette.primary
    },
    folderIcon: {
        color: colorPalette.primary
    },
    imgContainer: {
        position: 'absolute',
        marginTop: -170,
        background: '#fff',
        width: 200,
        height: 200,
        textAlign: 'center',
        borderRadius: 100,
        border: '0.01px solid rgba(17, 118, 140,0.4)'
    },
    flex: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 1 }
}));
function ProfileDetails(props) {
    const [profile, setProfile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [uploading, setUploading] = useState({ SOSD: null, EIN: null, DL: null });
    const [profilePicUploading, setProfilePicUploading] = useState(false);
    const classes = useStyles();
    useEffect(() => {
        getMyProfile();
    }, []);

    const getMyProfile = async () => {
        try {
            setLoading(true);
            const res = await getProfile();
            setProfile(res);
            setUser(res);
            setLoading(false);
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
        }
    }


    const onDownload = (document) => {
        window.open(document.url);
    }

    const onDocumentUpload = async (e) => {
        const { files, name } = e.target;
        if (files[0]) {
            try {
                let data = new FormData();
                data.append('file', files[0]);
                data.append('doc_type', name);
                setUploading(prevState => ({
                    ...prevState,
                    [name]: true
                }));
                const { success, message } = await uploadDocument(data);

                if (success) {
                    openComp({ compName: "snackbar", payload: { message } });
                    setUploading(prevState => ({
                        ...prevState,
                        [name]: false
                    }));
                }
            } catch (error) {
                const message = error.message || error;
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        }
    }

    const onChangeAvatar = async (e) => {
        const { files, name } = e.target;
        const image = files[0];
        const type = image.type.split('/')[1];
        if (type === 'jpg' || type === 'jpeg' || type === 'png') {
            try {
                let data = new FormData();
                data.append('file', files[0]);
                setProfilePicUploading(true);
                const res = await updateProfilePic(data);

                if (res.success) {
                    openComp({ compName: "snackbar", payload: { message: res.message, severity: 'success' } });
                    getMyProfile();
                }
                setProfilePicUploading(false);
            } catch (error) {
                const message = error.message || error;
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            openComp({ compName: "snackbar", payload: { message: 'Please upload profile picture with JPG/JPEG/PNG format.', severity: 'error' } })
        }

    }

    const renderProfileItem = (heading, subHeading, size = 6) => <Grid item container spacing={1} xs={12} sm={size}>
        <Grid item xs={12}>
            <Typography variant="subtitle1" style={{ fontSize: 14, fontWeight: '500', color: '#ccc' }}>{heading}</Typography>
        </Grid>
        <Grid item xs={12}>
            <Typography variant="h6" style={{ color: '#333', padding: 10, border: '1px solid #ccc', fontSize: 14, borderRadius: 5, background: '#f0f0f0' }}>
                {subHeading}
            </Typography>
        </Grid>
    </Grid>;
    return (
        <PageTag>
            <BarTag title="My Profile" back={false} drawer={true} profile={false} />
            {loading ?
                <div style={{ height: '80vh' }}><CircularLoader opened={loading} /></div>
                :
                profile &&
                <Container style={{ marginTop: -5 }}>

                    <Grid container spacing={1}>
                        <Grid item xs={12} sm={12}>
                            <Paper elevation={2} className={classes.paper}>

                                <Grid container spacing={2} style={{ marginTop: 40 }}>
                                    <Grid item xs={12} sm={12} className="flexCenterColumn">
                                        <div className={classes.imgContainer}>
                                            <div style={{ width: '100%', height: '100%', backgroundImage: `url(${profile.profile_pic ? profile.profile_pic : AVATAR})`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'contain', borderRadius: 100, }} />
                                            <IconButton
                                                disabled={profilePicUploading}
                                                component="label"
                                                style={{ boxShadow: BOX_SHADOW, position: 'absolute', transform: 'translate(33px, -52px)', backgroundColor: colorPalette.primary, color: '#fff', marginTop: 10, alignSelf: 'center' }}
                                                variant="contained">
                                                {profilePicUploading ? <CircularLoader color="inherit" size={20} opened={true} /> : <Icon style={{ fontSize: 20 }}>edit</Icon>}
                                                <input name='upload_pic' type='file' onChange={onChangeAvatar} hidden={true} accept="image/*" />
                                            </IconButton>

                                        </div>

                                    </Grid>
                                    <Grid item xs={12} sm={6} style={{ marginTop: 35 }}>
                                        <List>
                                            <ListSubheader disableSticky style={{ marginBottom: 20, display: 'flex' }}>
                                                <Typography variant={'h6'}>Profile</Typography>
                                                <Tooltip title="Edit Profile">
                                                    <IconButton
                                                        component={Link}
                                                        to="/editProfile"
                                                        style={{ marginTop: -5, alignSelf: 'center' }}
                                                        variant="text">
                                                        <Icon style={{ fontSize: 20 }}>edit</Icon>
                                                    </IconButton>
                                                </Tooltip>
                                            </ListSubheader>
                                            <ListItem className={classes.listItem}>
                                                <Grid container spacing={1}>
                                                    {renderProfileItem('First Name', profile.first_name)}
                                                    {renderProfileItem('Last Name', profile.last_name)}
                                                    {renderProfileItem('Company Name', profile.company_name)}
                                                    {renderProfileItem('Email', profile.email)}
                                                    {renderProfileItem('Operator', profile.operator)}
                                                    {renderProfileItem('Mobile', profile.mobile)}
                                                    {renderProfileItem('Business Type', profile.business_type)}
                                                    {renderProfileItem('Years In Business', profile.no_of_years_in_buisness)}
                                                    {renderProfileItem('Address', profile.address, 12)}
                                                </Grid>
                                            </ListItem>
                                        </List>
                                    </Grid>
                                    <Grid item xs={12} sm={6} style={{ marginTop: 40 }}>
                                        <List>
                                            <ListSubheader disableSticky><Typography variant={'h6'} style={{ marginBottom: 48 }}>Documents</Typography></ListSubheader>
                                            {profile.documents.map((document, key) => {
                                                return <ListItem key={key} elevation={2} style={{ padding: 15, background: 'rgba(240, 240, 240, 0.6)', marginTop: 20, border: '1px solid #ccc', borderRadius: 5 }}>
                                                    <ListItemIcon>
                                                        <FolderIcon className={classes.folderIcon} />
                                                    </ListItemIcon>
                                                    <Typography noWrap={false} className={classes.docListHeading}>{documentTypes[document.doc_type]}</Typography>
                                                    <ListItemSecondaryAction className={classes.flex}>
                                                        {document.is_approved ? <Tooltip title={"Approved"}>
                                                            <span className={classes.flex}>
                                                                <CheckCircleOutlineIcon style={{ fontSize: 23, color: colorPalette.success }} />
                                                            </span>
                                                        </Tooltip> :
                                                            <Tooltip title={"Pending"}>
                                                                <span className={classes.flex}>
                                                                    <UpdateIcon style={{ fontSize: 23, color: colorPalette.pending }} />
                                                                </span>
                                                            </Tooltip>}
                                                        <Tooltip title="Download Document">
                                                            <IconButton edge="end" aria-label="download" onClick={() => onDownload(document)}>
                                                                <CloudDownloadIcon className={classes.downloadIcon} />
                                                            </IconButton>
                                                        </Tooltip>
                                                        {<Tooltip title="Upload Document">
                                                            <span>
                                                                <IconButton
                                                                    disabled={document.is_approved}
                                                                    className={classes.button}
                                                                    component="label"
                                                                    variant="text">
                                                                    {uploading[document.doc_type] ? <CircularLoader opened={true} size={20} /> : <Icon className={classes.downloadIcon}>upload</Icon>}
                                                                    <input name={document.doc_type} type='file' onChange={onDocumentUpload} hidden={true} />
                                                                </IconButton>
                                                            </span>
                                                        </Tooltip>}
                                                    </ListItemSecondaryAction>

                                                </ListItem>
                                            })}
                                        </List>

                                    </Grid>
                                </Grid>
                            </Paper>
                        </Grid>
                        {/* */}
                    </Grid>
                </Container>
            }

        </PageTag>
    );
}


export default ProfileDetails;