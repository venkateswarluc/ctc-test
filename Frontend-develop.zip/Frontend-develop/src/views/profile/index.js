import React, { Fragment, useEffect, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import { connect } from "unistore/react";

//MAT-UI
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import Icon from '@material-ui/core/Icon';
import Divider from '@material-ui/core/Divider';


//AIUI 
import PageTag from "appRoot/tags/PageTag";
import BarTag from "appRoot/tags/BarTag";
import { openComp, resetComp } from "appRoot/uniStore/StateMgr";

import {  Logout } from "../../libs/apiProvider/apiProvider";
import { getUser } from "../../libs/sessionStorage/storageApis";



const ProfileView = ({ fireUser }) => {
    const history = useHistory();
    const [user, setUser] = useState(null);
    useEffect(() => {
        setUser(getUser());
    })
    return (
        <PageTag>
            <BarTag title="Profile" profile={false} />
            <div className="w3-content hasBoth">
                <div className="flexRow">

                    <div className="flexItem w480">
                        <div className="w3-margin-sm w3-container w3-center">
                            <Icon style={{ fontSize: '64px' }}>account_circle</Icon>
                            <Typography className="w3-caps" variant="h4" gutterBottom>{fireUser.group}</Typography>

                            <Divider />
                            <div className="w3-panel">
                                {/* {user === 'admin' && <Button variant="outlined" color="primary"
                                    component={Link} to={`/registerMerchant`}>
                                    Add Merchant
                                </Button>} */}
                                {user === 'merchant' && <Button variant="outlined" color="primary"
                                    component={Link} to={`/profileDetails`}>
                                    View Profile
                                </Button>}
                                <Button variant="contained" color="secondary" title="Logout" className="w3-margin-left-sm"
                                    onClick={() => {
                                        openComp({
                                            compName: 'confirm',
                                            payload: {
                                                opened: true,
                                                onDone: async (isOk) => {
                                                    if (isOk) {
                                                        Logout();
                                                        history.push('/login')
                                                    }
                                                    resetComp({ compName: "confirm" });
                                                }
                                            }
                                        })
                                    }}
                                >Sign Out</Button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </PageTag>

    )
};

export default connect(store => ({
    fireUser: store.auth.fireUser
}))(ProfileView)