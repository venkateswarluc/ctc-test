import React, { Fragment, useEffect, useState } from 'react';
import { Button, Card, CardContent, CardHeader, Container, Divider, Grid, Icon, IconButton, makeStyles, Tooltip } from '@material-ui/core';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import BackupIcon from '@material-ui/icons/Backup';
import AiLoader from 'appRoot/components/AiLoader';
import { openComp, setDocumentUpload } from "appRoot/uniStore/StateMgr";
import { useHistory } from 'react-router-dom';
import { connect } from 'unistore/react';
import useStyles from '../../libs/styleProvider';
import CircularLoader from '../../components/AiCircularLoader';
import Logo from '../../assets/logo.png';
import { GetDocumentSubmit, setIsDocumentSubmitted, } from '../../libs/sessionStorage/storageApis';
import { getProfile, Logout, uploadDocument } from '../../libs/apiProvider/apiProvider';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import { colorPalette } from '../../libs/styleProvider';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
function DocumentUpload(props) {
    const classes = useStyles();
    const [data, setData] = useState({ SOSD: { loading: false, isApproved: null, doc_type: 'SOSD', url: '', isUploaded: false }, EIN: { loading: false, isApproved: null, doc_type: 'EIN', url: '', isUploaded: false }, DL: { loading: false, isApproved: null, doc_type: 'DL', url: '', isUploaded: false } });
    const [loading, setLoading] = useState(false);
    const history = useHistory();
    const { documentStatus, fireUser } = props;


    useEffect(() => {
        // if(Number(GetDocumentSubmit()) === 3) {
        //     console.log('called');
        //     history.push('/');
        // }else {
        // }
        onProfile();
        
    }, []);
    const onProfile = async () => {
        try {
            setLoading(true);
            const profile = await getProfile();
            setLoading(false);
            profile.documents.forEach(document => {
                setData(prevState => ({
                    ...prevState,
                    [document.doc_type]: {
                        ...prevState[document.doc_type],
                        isApproved: document.is_approved,
                        doc_type: document.doc_type,
                        url: document.url
                    }
                }));
            })
        } catch (e) {
            console.log(e);
        }
    }
    const onSubmit = (e) => {
        e.preventDefault();
        const documents = GetDocumentSubmit();

        if (Number(documents) === 3) {
            openComp({ compName: "snackbar", payload: { message: "Successfully uploaded.", severity: 'success' } });
            setIsDocumentSubmitted(true);
            history.push('/');
            setDocumentUpload(true);
        } else {
            openComp({ compName: "snackbar", payload: { message: "Please upload all files.", severity: 'error' } });
        }
    }

    const onUpload = async (e) => {
        const { files, name } = e.target;
        if (files[0]) {
            try {
                let data = new FormData();
                data.append('file', files[0]);
                data.append('doc_type', name);
                setData(prevState => ({
                    ...prevState,
                    [name]: {
                        ...prevState[name],
                        loading: true
                    }
                }));
                const { success, message } = await uploadDocument(data);
                if (success) {
                    await onProfile();
                    openComp({ compName: "snackbar", payload: { message } });
                    setData(prevState => ({
                        ...prevState,
                        [name]: {
                            ...prevState[name],
                            loading: false,
                            isUploaded: true
                        }
                    }));
                }
            } catch (error) {
                const message = error.message || error;
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        }
    }

    const onSignOut = () => {
        Logout();
    }
    const onDownload = (document) => {
        window.open(document.url);
    }
    const renderDocItem = (label, type) => (
        <Grid item xs={12} className={classes.cardItem}>
            <label>{label}</label>
            <div className={classes.cardItem}>
                {type.isApproved !== null && <Tooltip title={type.isApproved ? "Approved" : "Pending"}>
                    <CheckCircleOutlineIcon style={{ color: !type.isApproved ? colorPalette.pending : colorPalette.success }} />
                </Tooltip>}
                <Tooltip title="Download Document">
                    <span>
                        <IconButton disabled={!type.url} edge="end" aria-label="download" onClick={() => onDownload(type)}>
                            <CloudDownloadIcon style={{ color: type.url && colorPalette.primary }} />
                        </IconButton>
                    </span>
                </Tooltip>
                <Tooltip title="Upload Document">
                    <IconButton
                        disabled={type.loading === 'uploading' || type.isApproved}
                        component="label"
                        variant="text">
                        {type.loading === true ? <CircularLoader opened={true} size={20} /> : <Icon style={{ color: colorPalette.primary }}>upload</Icon>}
                        <input name={type.doc_type} type='file' onChange={onUpload} hidden={true} />
                    </IconButton>
                </Tooltip>
            </div>
        </Grid>
    )
    return (
        <Fragment>
            <Container style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 25 }}>
                <Fragment>
                    <img alt="noola" src={Logo} className={classes.navImg} />
                    <br />
                </Fragment>
                <Button
                    onClick={onSignOut}
                    variant="contained" color="primary"
                    className={classes.button}
                >Sign Out</Button>
            </Container>

            {loading ?
                <div style={{ height: '80vh' }}><CircularLoader opened={loading} /></div>
                :
                <Container style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                    <Card elevation={12} className={classes.root}>
                        <CardHeader
                            className={classes.header}
                            title="Upload Documents" />
                        <CardContent>

                            <form onSubmit={onSubmit}>
                                <Grid container spacing={4} >
                                    {renderDocItem("Secretary of State Document(SOSD)*", data.SOSD)}
                                    {renderDocItem("Document containing EIN*", data.EIN)}
                                    <Divider />
                                    {renderDocItem("Driver's License*", data.DL)}
                                    <Divider />
                                    <Grid item xs={12}>
                                        <Button
                                            fullWidth={true}
                                            variant="contained"
                                            type="submit"
                                            className={classes.button}>
                                            {" "} Submit {" "}
                                        </Button>
                                    </Grid>
                                </Grid>
                            </form>
                        </CardContent>
                    </Card>
                </Container>
            }
        </Fragment>
    );
}

export default connect(store => {
    return {
        fireUser: store.auth.fireUser,
        documentStatus: store.documentStatus.documents
    }
})(DocumentUpload);