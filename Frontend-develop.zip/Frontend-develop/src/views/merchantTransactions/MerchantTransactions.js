import { Container, Grid, Paper, Tooltip, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router';
import { getWalletTransactions } from '../../libs/apiProvider/bankAPI';
import BarTag from '../../tags/BarTag';
import PageTag from '../../tags/PageTag';
import CircularLoader from '../../components/AiCircularLoader';
import CustomTable from '../../components/AiCustomTable/CustomTable';
import { customObject, numberWithCommas } from '../../libs/helper';
import { openComp } from '../../uniStore/StateMgr';
import UpdateIcon from '@material-ui/icons/Update';
import { colorPalette } from '../../libs/styleProvider';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
function MerchantTransactions(props) {
    const location = useLocation();
    const [data, setData] = useState([]);
    const [loader, setLoader] = useState(false);
    const [error, setError] = useState('');
    const [isBackButton, setBackButton] = useState(false);
    const [params, setParams] = useState(false);
    const [tableHead, setTableHead] = useState([]);
    useEffect(() => {
        getTransactions();
    }, []);

    const getTransactions = async () => {
        const params = {};
        if (location && location.search) {
            location.search.split('?')[1].split('&').map(param => {
                params[param.split('=')[0]] = param.split('=')[1];
            });
            params.transaction_source =  params.transaction_source.replace(/%20/g, ' ');
            setParams(params);
            if (params) {
                setBackButton(params.transaction_source != 'ALL');
                try {
                    setLoader(true);
                    const res = await getWalletTransactions(params.transaction_source, params.transaction_type);
                    setLoader(false);
                    if (res.error) {
                        setError(res.error.message);
                        return;
                        // openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                    }
                    if (!res.error && res.data.success) {
                        const walletTransactions = [];
                        res.data.data.wallet_transactions.map(transaction => {
                            walletTransactions.push({
                                id: transaction.transaction_id,
                                institution_name: transaction.institution_name,
                                account_name: transaction.account_name,
                                transaction_amount: numberWithCommas(transaction.transaction_amount),
                                account: `*******${transaction.account_mask}`,
                                transaction_type: transaction.transaction_type === 'CREDIT' ? "Added to Noola Wallet" : transaction.transaction_type === 'DEBIT' && 'Transferred to Bank Account',
                                account_type: transaction.account_type,
                                bank_transaction_status: transaction.bank_transaction_status === 'PENDING'
                                    ?
                                    <Tooltip title="Pending">
                                        <UpdateIcon style={{ color: colorPalette.pending }} />
                                    </Tooltip>
                                    :
                                    transaction.bank_transaction_status === 'SUCCESS' &&
                                    <Tooltip title="Success">
                                        <CheckCircleOutlineIcon style={{ color: colorPalette.success }} />
                                    </Tooltip>,
                                date: transaction.created_at.split('T')[0]
                            });
                        });
                        if(params.transaction_source === 'ALL') {
                            setTableHead([
                                { id: "institution_name", label: "Institution Name" },
                                { id: 'account_name', label: 'Account Name' },
                                { id: 'transaction_type', label: 'Transaction Type' },
                                { id: 'transaction_amount', label: 'Transaction Amount' },
                                { id: 'account', label: 'Account' },
                                { id: 'date', label: 'Date' },
                                { id: 'bank_transaction_status', label: 'Status' }
                            ]);
                            setData(customObject(walletTransactions, ['institution_name', 'account_name', 'transaction_type', 'transaction_amount', 'account', 'date', 'bank_transaction_status', 'id']));
                            return;    
                        }
                       const filteredTransactions = walletTransactions.filter(transaction => transaction.institution_name === params.transaction_source)
                        setTableHead([
                            // { id: "institution_name", label: "Institution Name" },
                            { id: 'account_name', label: 'Account Name' },
                            { id: 'transaction_type', label: 'Transaction Type' },
                            { id: 'transaction_amount', label: 'Transaction Amount' },
                            { id: 'account', label: 'Account' },
                            { id: 'date', label: 'Date' },
                            { id: 'bank_transaction_status', label: 'Status' }
                        ]);
                        setData(customObject(filteredTransactions, ['account_name', 'transaction_type', 'transaction_amount', 'account', 'date', 'bank_transaction_status', 'id']));
                    } 
                    
                } catch (error) {
                    setLoader(false);
                    setError(error.message);
                    // openComp({ compName: "snackbar", payload: { message: error.message, severity: 'error' } });
                }
            }
        }
    }
    return (
        <PageTag>
            <BarTag title={params.transaction_source === 'ALL' ? 'transactions' : params && params.transaction_source} drawer={!isBackButton} back={isBackButton} profile={true} dMode={false} />

            <Container>
                <Grid container style={{ paddingTop: 25 }}>
                    <Grid item container
                        xs={12}
                        direction="row"
                        justify="flex-end"
                        alignItems="flex-end">
                        {/* <Button variant="contained" className={classes.button}
                                component={Link} to={`/registerMerchant`}>
                                Add User
                            </Button> */}
                    </Grid>
                    {loader ?
                        <Grid item xs={12}>
                            <div style={{ height: '70vh' }}><CircularLoader opened={true} /></div>
                        </Grid>
                        :
                        <Grid item xs={12}>

                            {
                                error
                                    ?
                                    <Paper style={{ height: 200, padding: 25, textAlign: 'center' }}><p style={{ fontStyle: 'italic' }}>{error}</p></Paper>
                                    :
                                    <CustomTable
                                        // ID names should match with object of data
                                        tableHead={tableHead}
                                        data={data}
                                    // extraRows={renderTableButtons}
                                    />}
                        </Grid>
                    }
                </Grid>
            </Container>
        </PageTag>
    );
}

export default MerchantTransactions;