import { Container, Grid, makeStyles, Paper, Tooltip, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import { getMerchantTransactions } from '../../../libs/apiProvider/adminApi';
import { BORDER_RADIUS, BOX_SHADOW, colorPalette } from '../../../libs/styleProvider';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import CustomTable from '../../../components/AiCustomTable/CustomTable';
import CircularLoader from '../../../components/AiCircularLoader';
import BarTag from '../../../tags/BarTag';
import PageTag from '../../../tags/PageTag';
import { customObject, numberWithCommas } from '../../../libs/helper';
import UpdateIcon from '@material-ui/icons/Update';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
const useStyles = makeStyles(theme => ({
    paper: {
        minHeight: 200,
        background: '#fff',
        boxShadow: BOX_SHADOW,
        borderRadius: BORDER_RADIUS,
        padding: 25
    }
}));
function Transactions(props) {
    const classes = useStyles();
    const [loader, setLoader] = useState(false);
    const [error, setError] = useState('');
    const [data, setData] = useState([]);
    const [tableHead, setTableHead] = useState([]);
    useEffect(() => {
        getTransactions();
    }, []);

    const getTransactions = async () => {
        try {
            if (!location.search.includes('id')) return;
            setLoader(true);
            const customer_id = location.search.split('=')[1];
            const res = await getMerchantTransactions({ customer_id });
            
            const transactions = res.data.data.wallet_transactions.map(transaction => ({
                institution_name: transaction.institution_name,
                account_name: transaction.account_name,
                transaction_type:  transaction.transaction_type === 'CREDIT' ? "Added to Noola Wallet" : transaction.transaction_type === 'DEBIT' && 'Transferred to Bank Account',
                transaction_amount: numberWithCommas(transaction.transaction_amount),
                account_mask: '********'+transaction.account_mask,
                updated_at: transaction.updated_at.split('T')[0],
                status: transaction.status === 'PENDING'
                ?
                <Tooltip title="Pending">
                    <UpdateIcon style={{ color: colorPalette.pending }} />
                </Tooltip>
                :
                transaction.bank_transaction_status === 'SUCCESS' &&
                <Tooltip title="Success">
                    <CheckCircleOutlineIcon style={{ color: colorPalette.success }} />
                </Tooltip>,
                id: transaction.transaction_id
            }));

            const tableHead = [
                {id: 'institution_name', label: 'Institution Name'},
                { id: 'account_name', label: 'Account Name'},
                { id: 'transaction_type', label: 'Transaction Type'},
                { id: 'transaction_amount', label: 'Transaction Amount'},
                { id: 'account_mask', label: 'Account'},
                { id: 'date', label: 'Date'},
                { id: 'status', label: 'Status'}
            ]
            setData(transactions);
            setTableHead(tableHead);
            setLoader(false);
        } catch (e) {
            setError(e.message);
            setLoader(false);
            console.log('error occurred', e);
        }
    }
    return (
        <PageTag>
            <BarTag title="Transactions" drawer={false} back={true} profile={true} dMode={false} />
            <Container style={{marginTop: 25}}>
                <Grid container>
                    <Grid item xs={12}>

                    </Grid>
                    <Grid item xs={12}>
                        {
                            error ?
                                <Paper className={classes.paper}>
                                    <div style={{ textAlign: 'center', padding: 40 }}>
                                        <AccountBalanceWalletIcon style={{ fontSize: 200, color: '#f0f0f0' }} />
                                        <Typography variant="h6" style={{ color: '#ccc' }}>{error}</Typography>
                                    </div>
                                </Paper>
                                :
                                loader ?
                                    <div style={{ height: '70vh' }}><CircularLoader opened={true} /></div>
                                    :
                                   <CustomTable
                                    tableHead={tableHead}
                                    data={data} />
                        }
                    </Grid>
                </Grid>
            </Container>
        </PageTag>
    );
}

export default Transactions;