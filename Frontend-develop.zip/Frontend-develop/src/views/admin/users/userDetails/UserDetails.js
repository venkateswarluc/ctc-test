import React from 'react';

function UserDetails(props) {
    return (
        <div>
            
        </div>
    );
}

export default UserDetails;