import { Button, Container, Grid } from '@material-ui/core';
import React, { Fragment, useEffect, useState } from 'react';
import { deactivateUser, getUsers } from '../../../../libs/apiProvider/adminApi';
import useStyles, { colorPalette } from '../../../../libs/styleProvider';
import BarTag from '../../../../tags/BarTag';
import PageTag from '../../../../tags/PageTag';
import { openComp, resetComp } from '../../../../uniStore/StateMgr';
import CircularLoader from '../../../../components/AiCircularLoader';
import { Link } from 'react-router-dom';
import CustomTable from '../../../../components/AiCustomTable/CustomTable';
import { customObject } from '../../../../libs/helper';
import TableButton from '../../../../components/AiCustomTable/Button';
function UsersList(props) {
    const classes = useStyles();
    const [data, setData] = useState([]);
    const [loader, setLoader] = useState(false);
    useEffect(() => {
        onGetUsers();
    }, []);

    const onGetUsers = async () => {
        try {
            setLoader(true);
            const res = await getUsers();
            setLoader(false);
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            if (res.data.success) {

                const newUsers = [];
                res.data.data.users.map(user => {
                    newUsers.push({
                        id: user.id,
                        name: user.name,
                        mobile: `${user.country_code} ${user.mobile}`,
                        is_active: user.is_active
                    });
                });
                setData(newUsers.reverse());
            }
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
            console.log("Error Occurred while fetching users", e);
        }
    }


    const blockUser = async (user) => {
        try {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            const res = await deactivateUser({user_id: user.id});
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            resetComp({ compName: "dialog" });
            if(res.data.success) {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                onGetUsers();
            }
        }catch(e) {

        }
    }

    const openConfirm = (item) => {
        openComp({
            compName: 'dialog',
            payload: {
                opened: true,
                title: "Block user",
                warning: <span style={{ fontStyle: 'italic' }}>*Do you want to block {item.name.toUpperCase()}?</span>,
                children: 'Block',
                onDone: async (isOk) => {
                    if (isOk) {
                        blockUser(item);
                    } else {
                        resetComp({ compName: "dialog" });
                    }
                }
            }
        });
    }
    const renderTableButtons = (item) => {
        return [<Fragment>
            {/* <TableButton btnType="success" style={{ marginRight: 2 }}>
                View
            </TableButton> */}
            <TableButton type="text" disabled={!item.is_active} btnType="danger" onClick={() => openConfirm(item)}>
                {item.is_active ? 'Block' : 'Blocked'}
            </TableButton>
        </Fragment>];
    }
    return (
        <PageTag>
            <BarTag title="Users" drawer={true} back={false} profile={true} dMode={false} />
            <Container>
                <Grid container style={{ paddingTop: 25 }}>
                    <Grid item container
                        xs={12}
                        direction="row"
                        justify="flex-end"
                        alignItems="flex-end">
                        {/* <Button variant="contained" className={classes.button}
                                component={Link} to={`/registerMerchant`}>
                                Add User
                            </Button> */}
                    </Grid>
                    {loader ?
                        <Grid item xs={12}>
                            <div style={{ height: '70vh' }}><CircularLoader opened={true} /></div>
                        </Grid>
                        :
                        <Grid item xs={12}>
                            <CustomTable
                                // ID names should match with object of data
                                tableHead={[
                                    { id: "name", label: "Name" },
                                    { id: 'mobile', label: 'Mobile' },
                                    { id: 'is_active', label: 'Is Active' },
                                    { id: 'actions', label: 'Actions' }
                                ]}
                                data={customObject(data, ['name', 'mobile', 'is_active', 'id'])}
                                extraRows={renderTableButtons}
                            />
                        </Grid>
                    }
                </Grid>
            </Container>
        </PageTag>
    );
}

export default UsersList;