import React, { useEffect, useState } from 'react';
import BarTag from '../../../tags/BarTag';
import PageTag from '../../../tags/PageTag';

import AiForm, { AiInput, AiSelect } from '../../../components/AiForm';
import { Button, Container, Grid, Icon, IconButton, makeStyles, Typography } from '@material-ui/core';
import { useHistory } from 'react-router';
import CircularLoader from '../../../components/AiCircularLoader';
import { phoneValidate, validateEmail } from "appRoot/libs/helper";
import { openComp } from '../../../uniStore/StateMgr';
import AiLoader from "appRoot/components/AiLoader";
import AVATAR from '../../../assets/avatar.jpg';
import { BOX_SHADOW, colorPalette } from '../../../libs/styleProvider';
import { getMerchantDetails, updateMerchantProfilePic, updateMerchant } from '../../../libs/apiProvider/adminApi';
import { getMerchantStoreCategories } from '../../../libs/apiProvider/apiProvider';
const useStyles = makeStyles(theme => ({
    imgContainer: {
        position: 'absolute',
        marginTop: -150,
        background: '#fff',
        width: 200,
        height: 200,
        textAlign: 'center',
        borderRadius: 100,
        border: '0.01px solid rgba(17, 118, 140,0.4)'
    },
    addMerchantFormContainer: {
        background: '#fff',
        boxShadow: '0px 14px 80px rgba(34, 35, 58, 0.2)',
        borderRadius: 15,
        transition: 'all .3s',

        [theme.breakpoints.up('xs')]: {
            width: '80%',
            padding: '40px 55px 45px 55px',

        },
        [theme.breakpoints.down('sm')]: {
            width: '90%',
            padding: '40px 15px 25px 15px',
        }
    }
}));
function EditMerchant(props) {
    const classes = useStyles();
    const history = useHistory();

    const [isLoader, setIsLoader] = useState(false);

    const [first_name, setFirstName] = useState('');
    const [last_name, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [company_name, setCompany_name] = useState('');
    const [address, setAddress] = useState('');
    const [operator, setOperator] = useState('');
    const [mobile, setMobile] = useState(0);
    const [businessType, setBusinessType] = useState('');
    const [yearsInBusiness, setYearsInBusiness] = useState('');
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(false);
    const [profile, setProfile] = useState(false);
    const [profilePicUploading, setProfilePicUploading] = useState(false);
    useEffect(() => {
        onProfile();
        
    }, []);


    const getStoreCategories = async () => {
        try {
            const res = await getMerchantStoreCategories();
            if (!res.error && res.data.success) {
                const storeCategories = res.data.data.store_categories.map((category, index) => ({ value: index, label: category }));
                setCategories(storeCategories);
                return storeCategories;
            }
        } catch (e) {
            console.log("Error while getting categories", e);
        }
    }

    const onProfile = async () => {
        setLoading(true);
        if (location.search.includes('id')) {
            const id = location.search.split('=')[1];
            const res = await getMerchantDetails(id);
            const storeCategories = await getStoreCategories();
            setProfile(res.data.data.merchant);
            const businessType = storeCategories.find(type => type.label === res.data.data.merchant.business_type);
            setLoading(false);
            setFirstName(res.data.data.merchant.first_name || "");
            setLastName(res.data.data.merchant.last_name || "");
            setEmail(res.data.data.merchant.email);
            setCompany_name(res.data.data.merchant.company_name || "");
            setOperator(res.data.data.merchant.operator || "");
            setMobile(res.data.data.merchant.mobile || "");
            setBusinessType(businessType ? businessType.value : '');
            setYearsInBusiness(res.data.data.merchant.no_of_years_in_buisness || "");
            setAddress(res.data.data.merchant.address || "");
        }


    }
    const onSubmit = async () => {
        if (!location.search.includes('id')) return;
        setIsLoader(true);
        if (first_name.length && last_name.length && company_name.length && address.length && operator.length && phoneValidate(mobile) && categories[businessType] && parseInt(yearsInBusiness) >= 0) {

            const data = {
                merchant_id: location.search.split('=')[1],
                first_name,
                last_name,
                company_name,
                address,
                operator,
                mobile,
                business_type: categories[businessType].label,
                no_of_years_in_buisness: yearsInBusiness
            }
            try {
                const res = await updateMerchant(data);
                if (res.data.success) {
                        openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                        history.goBack();
                    }

            } catch (error) {
                const message = error.message || error;
                setIsLoader(false);
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
         
            openComp({ compName: "snackbar", payload: { message: 'Please fill all the fields.', severity: 'warning' } });
        }
        setIsLoader(false);
    }

    const onChangeAvatar = async (e) => {
        const { files, name } = e.target;
        const image = files[0];
        const type = image.type.split('/')[1];
        if (!location.search.includes('id')) return;
        if (type === 'jpg' || type === 'jpeg' || type === 'png') {
            try {
                let data = new FormData();
                data.append('file', files[0]);
                setProfilePicUploading(true);
                const id = location.search.split('=')[1];
                data.append('merchant_id', id);
                const res = await updateMerchantProfilePic(data);
                if (res.data.success) {
                    openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                    onProfile();
                }
                setProfilePicUploading(false);
            } catch (error) {
                setProfilePicUploading(false);
                const message = error.message || error;
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            openComp({ compName: "snackbar", payload: { message: 'Please upload profile picture with JPG/JPEG/PNG format.', severity: 'error' } })
        }

    }

    return (
        <PageTag>
            <BarTag title="Update Profile" drawer={false} back={true} profile={false} dMode={false} />
            {loading ?
                <div style={{ height: '80vh' }}><CircularLoader opened={loading} /></div>
                :

                <>
                    <div style={{ marginTop: 130, marginBottom: 4 }}>
                    </div>
                    <Container className={classes.addMerchantFormContainer}>
                        <AiForm onDone={onSubmit} style={{ color: "#127598" }}>
                            <Grid container spacing={10}>
                                <Grid item xs={12} sm={12} className="flexCenterColumn">
                                    <div className={classes.imgContainer}>
                                        <div style={{ width: '100%', height: '100%', backgroundImage: `url(${profile.profile_pic ? profile.profile_pic : AVATAR})`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'contain', borderRadius: 100, }} />
                                        <IconButton
                                            disabled={profilePicUploading}
                                            component="label"
                                            style={{ boxShadow: BOX_SHADOW, position: 'absolute', transform: 'translate(33px, -40px)', backgroundColor: colorPalette.primary, color: '#fff', alignSelf: 'center' }}
                                            variant="contained">
                                            {profilePicUploading ? <CircularLoader color="inherit" size={20} opened={true} /> : <Icon style={{ fontSize: 20 }}>edit</Icon>}
                                            <input name='upload_pic' type='file' onChange={onChangeAvatar} hidden={true} accept="image/*" />
                                        </IconButton>

                                    </div>

                                </Grid>
                                <Grid container item spacing={2}>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" style={{ color: "#127598" }}>Email</Typography>
                                        <AiInput type="email" autoComplete="email" disabled={true}
                                            value={email}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >First Name</Typography>
                                        <AiInput
                                            type="text"
                                            id="first name"
                                            autoComplete="text"
                                            value={first_name}
                                            onChange={(e) => { setFirstName(e.target.value) }}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >Last Name</Typography>
                                        <AiInput
                                            id="Last Name"
                                            type="text"
                                            autoComplete="text"
                                            value={last_name}
                                            onChange={(e) => { setLastName(e.target.value) }}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >Company Name</Typography>
                                        <AiInput type="text" autoComplete="text"
                                            value={company_name}
                                            onChange={(e) => { setCompany_name(e.target.value) }}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >Operator</Typography>
                                        <AiInput type="text" autoComplete="text"
                                            value={operator}
                                            onChange={(e) => { setOperator(e.target.value) }}
                                        /></Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >Mobile</Typography>
                                        <AiInput type="tel"
                                            value={mobile != '' ? mobile : ''}
                                            onChange={(e) => { e.target.validity.valid && setMobile(e.target.value); }}
                                            error={mobile != '' && !phoneValidate(mobile)}
                                            helperText={mobile != '' && !phoneValidate(mobile) ? 'Mobile Number is invalid' : ''}
                                            inputProps={{
                                                pattern: "[0-9]*",
                                                maxLength: 10
                                            }}
                                        /></Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial" >Business Type</Typography>
                                        <AiSelect
                                            disabled={!categories.length}
                                            name="businessType"
                                            options={categories}
                                            value={businessType}
                                            onChange={({ target: { value } }) => { setBusinessType(value) }}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={4}>
                                        <Typography color="initial">Years In Business</Typography>
                                        <AiInput type="tel"
                                            value={yearsInBusiness != '' ? yearsInBusiness : ''}
                                            onChange={(e) => { e.target.validity.valid && setYearsInBusiness(e.target.value) }}
                                            error={yearsInBusiness < 0}
                                            helperText={yearsInBusiness < 0 ? 'Min. 0' : ''}
                                            inputProps={{
                                                pattern: "[0-9]*",
                                                maxLength: 4
                                            }}
                                        />
                                    </Grid>

                                    <Grid item xs={12}>
                                        <Typography color="initial" >Address</Typography>
                                        <AiInput type="textarea" autoComplete="text"
                                            value={address}
                                            onChange={(e) => { setAddress(e.target.value) }}
                                        />
                                    </Grid>
                                    <Grid item container direction="row"
                                        justify="center"
                                        alignItems="center" xs={12}>
                                        <Grid item xs={5}>
                                            {!isLoader
                                                ? <Button fullWidth size="large" variant="contained" type="submit" style={{ backgroundColor: "#127598", color: "white" }}>Update</Button>
                                                :
                                                <AiLoader color="secondary" opened={true} />
                                            }
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>


                        </AiForm>
                    </Container>
                    <div style={{ height: 30 }}></div>
                </>
            }
        </PageTag>
    );
}

export default EditMerchant;