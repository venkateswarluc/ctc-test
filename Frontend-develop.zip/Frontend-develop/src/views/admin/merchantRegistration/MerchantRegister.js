import React, { useEffect, useState } from 'react';

import AiForm, { AiInput, AiSelect } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";
import { getMerchantStoreCategories, registerMerchant, updateProfilePic } from "../../../libs/apiProvider/apiProvider";
import { phoneValidate, validateEmail } from "appRoot/libs/helper";
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';


import { connect } from 'unistore/react';
import { Button, Container, Icon, IconButton, makeStyles } from '@material-ui/core';
import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import { useHistory } from 'react-router-dom';
import BarTag from "appRoot/tags/BarTag";
import PageTag from "appRoot/tags/PageTag";
const useStyles = makeStyles(theme => ({
    addMerchantFormContainer: {
        background: '#fff',
        boxShadow: '0px 14px 80px rgba(34, 35, 58, 0.2)',
        borderRadius: 15,
        transition: 'all .3s',
        alignSelf: 'center',
        [theme.breakpoints.up('xs')]: {
            width: 700,
            padding: '40px 55px 45px 55px',

        },
        [theme.breakpoints.down('sm')]: {
            width: '90%',
            padding: '40px 55px 25px 15px',
        }
    }
}));
function MerchantRegister(props) {
    const { isLoaded } = props;
    if (!isLoaded) {
        return null;
    }


    const [isLoader, setIsLoader] = useState(false);
    const [email, setEmail] = useState('');
    const [first_name, setFirstName] = useState('');
    const [last_name, setLastName] = useState('');
    const [company_name, setCompany_name] = useState('');
    const [address, setAddress] = useState('');
    const [operator, setOperator] = useState('');
    const [mobile, setMobile] = useState(0);
    const [businessType, setBusinessType] = useState('');
    const [yearsInBusiness, setYearsInBusiness] = useState('');
    const businessTypeArr = [{ value: 0, label: 'Store' }];
    const [categories, setCategories] = useState([]);
    const history = useHistory();
    const classes = useStyles();

    useEffect(() => {
        const storesAPI = getStoreCategories();

        return () => storesAPI;
    }, []);

    const getStoreCategories = async () => {
        try {

            const res = await getMerchantStoreCategories();
            if (!res.error && res.data.success) {
                const storeCategories = res.data.data.store_categories.map((category, index) => ({ value: index, label: category }));
                setCategories(storeCategories);
            }
        } catch (e) {
            console.log("Error while getting categories", e);
        }

    }

    const onSubmit = async (form) => {
        setIsLoader(true);

        if (first_name.length && last_name.length
            && validateEmail(email) && company_name.length
            && address.length && operator.length
            && phoneValidate(mobile) && categories[businessType] 
            && parseInt(yearsInBusiness) >= 0) {

            const data = {
                email,
                first_name,
                last_name,
                company_name,
                address,
                operator,
                mobile,
                business_type: categories[businessType].label,
                no_of_years_in_buisness: yearsInBusiness
            }
            try {
                const { success, message } = await registerMerchant(data);
                if (success) {
                    openComp({ compName: "snackbar", payload: { message } });
                    history.push('/merchantList');
                }
            } catch (error) {
                const message = error.message || error;
               
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            openComp({ compName: "snackbar", payload: { message: 'Please fill all the fields.', severity: 'warning' } });
        }
        setIsLoader(false);
    }


    return (
        <PageTag>
            <BarTag title="Merchant Registration" drawer={false} back={true} profile={false} dMode={false} />
            <div style={{ marginTop: 25, marginBottom: 4 }}>
            </div>
            <Container className={classes.addMerchantFormContainer}>
                <AiForm onDone={onSubmit} style={{ color: "#127598" }}>
                    <Grid container spacing={6}>

                        <Grid container item spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" style={{ color: "#127598" }}>Email</Typography>
                                <AiInput type="email" autoComplete="email" required
                                    value={email}
                                    onChange={(e) => { setEmail(e.target.value) }}
                                    error={(email != '' && !validateEmail(email))}
                                    helperText={(email != '' && !validateEmail(email)) ? 'Email Invalid' : ''}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" style={{ color: "#127598" }}>First Name</Typography>
                                <AiInput type="text"
                                    autoComplete="text"
                                    id={"first_name"}
                                    value={first_name}
                                    onChange={(e) => { setFirstName(e.target.value) }}
                                    required
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" style={{ color: "#127598" }}>Last Name</Typography>
                                <AiInput type="text"
                                    autoComplete="text"
                                    id={"last_name"}
                                    value={last_name}
                                    onChange={(e) => { setLastName(e.target.value) }}
                                    required
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>

                                <Typography color="initial" >Company Name</Typography>

                                <AiInput type="text" autoComplete="text"
                                    value={company_name}
                                    onChange={(e) => { setCompany_name(e.target.value) }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" >Operator</Typography>
                                <AiInput type="text" autoComplete="text"
                                    value={operator}
                                    onChange={(e) => { setOperator(e.target.value) }}
                                /></Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" >Mobile</Typography>
                                <AiInput type="tel"
                                    value={mobile != '' ? mobile : ''}
                                    onChange={(e) => { e.target.validity.valid && setMobile(e.target.value); }}
                                    error={mobile != '' && !phoneValidate(mobile)}
                                    helperText={mobile != '' && !phoneValidate(mobile) ? 'Mobile Number is invalid' : ''}
                                    inputProps={{
                                        pattern: "[0-9]*",
                                        maxLength: 10
                                    }}
                                /></Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial" >Business Type</Typography>
                                <AiSelect
                                    disabled={!categories.length}
                                    name="businessType"
                                    options={categories}
                                    value={businessType}
                                    onChange={({ target: { value } }) => { setBusinessType(value) }}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <Typography color="initial">Years In Business</Typography>
                                <AiInput type="tel"
                                    value={yearsInBusiness != '' ? yearsInBusiness : ''}
                                    onChange={(e) => { e.target.validity.valid && setYearsInBusiness(e.target.value) }}
                                    error={yearsInBusiness < 0}
                                    helperText={yearsInBusiness < 0 ? 'Min. 0' : ''}
                                    inputProps={{
                                        pattern: "[0-9]*",
                                        maxLength: 4
                                    }}
                                />
                            </Grid>

                            <Grid item xs={12}>
                                <Typography color="initial" >Address</Typography>
                                <AiInput type="textarea" autoComplete="text"
                                    value={address}
                                    onChange={(e) => { setAddress(e.target.value) }}
                                    inputProps={{
                                        maxLength: 250
                                    }}
                                />
                            </Grid>
                            <Grid item container direction="row"
                                justify="center"
                                alignItems="center" xs={12}>
                                <Grid item xs={8}>
                                    {!isLoader
                                        ? <Button fullWidth size="large" variant="contained" type="submit" style={{ backgroundColor: "#127598", color: "white" }}>Add Merchant</Button>
                                        :
                                        <AiLoader color="secondary" opened={true} />
                                    }
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>


                </AiForm>
            </Container>

        </PageTag>
    );
}


export default connect(store => ({
    isLoaded: store.auth.isLoaded,
}))(MerchantRegister);