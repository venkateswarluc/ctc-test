import { Button, Container, Grid, Icon, Tooltip } from '@material-ui/core';
import React, { Fragment, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'unistore/react';
import CustomTable from '../../../components/AiCustomTable/CustomTable';
import CircularLoader from '../../../components/AiCircularLoader';
import { deactivateMerchant, getAllMerchants } from '../../../libs/apiProvider/adminApi';
import useStyles, { colorPalette } from '../../../libs/styleProvider';
import BarTag from '../../../tags/BarTag';
import PageTag from "../../../tags/PageTag";
import { openComp, resetComp } from '../../../uniStore/StateMgr';
import { customObject } from '../../../libs/helper';
import TableButton from '../../../components/AiCustomTable/Button';
import AVATAR from '../../../assets/avatar.jpg';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import UpdateIcon from '@material-ui/icons/Update';
function MerchantList(props) {
    const classes = useStyles();
    const [data, setData] = useState([]);
    const [loader, setLoader] = useState(false);

    useEffect(() => {
        fetchAllMerchants();
    }, []);

    const merchantPic = (source) => <img style={{ width: 40, height: 40, borderRadius: 100, objectFit: 'contain', border: '0.4px solid #ccc' }} src={source} />;
    const merchantStatus = (Icon, status) => <Tooltip title={status}>
        <Icon className={classes.statusIcon} style={{ color: status === 'Approved' ? colorPalette.success : colorPalette.pending }} />
    </Tooltip>;
    const fetchAllMerchants = async () => {
        try {
            ['company_name', 'email', 'mobile', 'address', 'is_approved', 'is_active', 'id']
            setLoader(true);
            const { data } = await getAllMerchants();
            if (data.success) {

                const merchants = data.data.merchants.reverse().map(merchant => ({
                    profile_pic: !merchant.profile_pic ? merchantPic(AVATAR) : merchantPic(merchant.profile_pic),
                    company_name: merchant.company_name,
                    email: merchant.email,
                    mobile: merchant.mobile,
                    address: merchant.address,
                    is_approved: merchant.is_approved ? merchantStatus(CheckCircleOutlineIcon, "Approved") : merchantStatus(UpdateIcon, "Pending"),
                    is_active: merchant.is_active,
                    id: merchant.id
                }));

                setData(merchants);
            }
            setLoader(false);
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
        }
    };

    const onDeactivateMerchant = async (merchant) => {
        try {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            const res = await deactivateMerchant({ merchant_id: merchant.id });
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            resetComp({ compName: "dialog" });
            if (res.data.success) {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                fetchAllMerchants();
            }
        } catch (e) {
            console.log(e);
        }
    };

    const openConfirm = (item) => {
        openComp({
            compName: 'dialog',
            payload: {
                opened: true,
                title: "De-activate Merchant",
                warning: <span style={{ fontStyle: 'italic' }}>{`*Are you sure you want to De-activate ${item.company_name.toUpperCase()}?`}</span>,
                children: 'De-activate',
                onDone: async (isOk) => {
                    if (isOk) {
                        onDeactivateMerchant(item);
                    } else {
                        resetComp({ compName: "dialog" });
                    }
                }
            }
        });
    }
    const renderTableButtons = (item) => {
        const FONT_SIZE = 9.2;
        return [
            <div style={{ minWidth: 320 }}>
            <TableButton component={Link} to={`/merchantDetails?id=${item.id}`} btnType="success" style={{ marginRight: 2, fontSize: FONT_SIZE }}>
                View
            </TableButton>
            <TableButton component={Link} to={`/editMerchant?id=${item.id}`} btnType="primary" style={{ marginRight: 2, fontSize: FONT_SIZE }}>
                Update
            </TableButton>
            <TableButton component={Link} to={`/transactions?id=${item.id}`} btnType="success" style={{ marginRight: 2, fontSize: FONT_SIZE, background: '#f2a22c' }}>
                Transactions
            </TableButton>
            <TableButton type="text" disabled={!item.is_active} btnType="danger" onClick={() => openConfirm(item)} style={{ fontSize: item.is_active ? FONT_SIZE : 8  }}>
                {item.is_active ? "DeActivate" : "Deactivated"}
            </TableButton>
        </div>
        ];
    }
    return (
        <PageTag>
            <BarTag title="Merchants" drawer={true} back={false} profile={true} dMode={false} />
            <Container>
                <Grid container style={{ paddingTop: 25 }}>
                    <Grid item container
                        xs={12}
                        direction="row"
                        justify="flex-end"
                        alignItems="flex-end">
                        <Button variant="contained" className={classes.button}
                            component={Link} to={`/registerMerchant`}>
                            Add Merchant
                        </Button>
                    </Grid>
                    {loader ?
                        <Grid item xs={12}>
                            <div style={{ height: '70vh' }}><CircularLoader opened={true} /></div>
                        </Grid>
                        :
                        <Grid item xs={12}>
                            <CustomTable
                                // ID names should match with object of data
                                tableHead={[
                                    { id: "profile_pic", label: "" },
                                    { id: "company_name", label: "Company Name" },
                                    { id: 'email', label: 'Email' },
                                    { id: 'mobile', label: 'Mobile' },
                                    { id: 'address', label: 'Address' },
                                    { id: 'is_approved', label: 'Approved' },
                                    { id: 'is_active', label: 'Active' },
                                    { id: 'actions', label: 'Actions' },
                                ]}
                                data={data}
                                link="/merchantDetails"
                                extraRows={renderTableButtons}
                            />
                        </Grid>
                    }
                </Grid>
            </Container>

        </PageTag>
    );
}

export default connect(store => ({
    confirm: store.confirm,
    snackbar: store.snackbar,
    documentStatus: store.documentStatus.documents,
    fireUser: store.auth.fireUser
}))(MerchantList);