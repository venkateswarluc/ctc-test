import React, { useEffect, useState } from 'react';
import { useLocation, useParams } from 'react-router';
import { approveDocument, approveMerchant, getMerchantDetails } from '../../../libs/apiProvider/adminApi';
// import { useLocation, useParams } from 'react-router';
import BarTag from '../../../tags/BarTag';
import PageTag from '../../../tags/PageTag';
import CircularLoader from '../../../components/AiCircularLoader';
import { Button, Chip, CircularProgress, Container, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Divider, Grid, Icon, IconButton, List, ListItem, ListItemIcon, ListItemSecondaryAction, ListSubheader, makeStyles, Paper, Tooltip, Typography, useTheme, withStyles } from '@material-ui/core';
import FolderIcon from '@material-ui/icons/Folder';
import CloudDownloadIcon from '@material-ui/icons/CloudDownload';
import { BORDER_RADIUS, BOX_SHADOW, colorPalette } from '../../../libs/styleProvider';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import { openComp, resetComp } from '../../../uniStore/StateMgr';
import AVATAR from '../../../assets/avatar.jpg';
import { documentTypes } from '../../../libs/helper';
import { Link } from 'react-router-dom';
const useStyles = makeStyles((theme) => ({
    paper: {
        padding: 15,
        paddingTop: 20,
        wordWrap: "break-word",
        borderRadius: BORDER_RADIUS,
        boxShadow: BOX_SHADOW,
        marginBottom: 20,
        marginTop: 70
    },
    approveButton: {
        "&:hover": {
            backgroundColor: 'transparent'
        },
        cursor: 'default'
    },
    list: {
        wordWrap: 'break-word'
    },
    listItem: {
        paddingBlock: 0,
        wordBreak: 'break-all'
    },
    docListHeading: {
        fontWeight: '700',
        width: '100%',
        [theme.breakpoints.down('xs')]: {
            fontSize: 14,
            marginLeft: -10,
            width: '50%'
        }
    },
    downloadIcon: {
        color: colorPalette.primary
    },
    folderIcon: {
        color: colorPalette.primary
    },
    imgContainer: {
        position: 'absolute',
        marginTop: -130,
        background: '#fff',
        width: 200,
        height: 200,
        textAlign: 'center',
        borderRadius: 100,
        border: '0.01px solid rgba(17, 118, 140,0.4)'
    },
    flex: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 1 }
}));

function MerchantDetails(props) {
    const params = useLocation();
    const classes = useStyles();
    const [loading, setLoading] = useState(false);
    const [merchant, setMerchant] = useState(null);
    const [dialog, setDialog] = useState({
        title: '',
        warning: '',
        open: false,
        loading: false
    });
    const [document, setDocument] = useState(null);

    useEffect(() => {
        getMerchant();
    }, []);


    const getMerchant = async () => {
        try {
            if (params && params.search) {
                setLoading(true);
                const id = params.search.split('=')[1];
                const res = await getMerchantDetails(id);
                if (res.data.success) {
                    setMerchant(res.data.data.merchant);
                }
                setLoading(false);
            }
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
        }
    }

    const onDialogOpen = (document) => {
        if (!document.is_approved) {

            const data = {
                merchant_id: params.search.split('=')[1],
                doc_id: document.id,
                doc_type: document.doc_type
            };
            setDocument(data);
            openComp({
                compName: 'dialog',
                payload: {
                    opened: true,
                    title: "Are you sure?",
                    warning: <span style={{ fontStyle: 'italic' }}>*Are you sure that you have gone through the document?</span>,
                    loading: dialog.loading,
                    children: 'Approve',
                    onDone: async (isOk) => {
                        if (isOk) {
                            onApprove(data, approveDocument);
                        } else {
                            resetComp({ compName: "dialog" });
                        }
                    }
                }
            });
        }
    }

    const approveProfile = async () => {
        const data = {
            merchant_id: params.search.split('=')[1]
        };
        openComp({
            compName: 'dialog',
            payload: {
                opened: true,
                title: "Are you sure?",
                warning: <span style={{ fontStyle: 'italic' }}>*On approve profile, documents will also be approved.</span>,
                children: 'Approve',
                onDone: async (isOk) => {
                    if (isOk) {
                        onApprove(data, approveMerchant);
                    } else {
                        resetComp({ compName: "dialog" });
                    }
                }
            }
        });
    }

    const onApprove = async (document, approveApi) => {
        try {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            const res = await approveApi(document);
            if (res.data.success) {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                getMerchant();
            }

            resetComp({ compName: "dialog" });
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
        }

    }
    const onDownload = (document) => {
        window.open(document.url);
    }

    const renderProfileItem = (heading, subHeading, size = 6) => <Grid item container spacing={1} xs={12} sm={size}>
        <Grid item xs={12}>
            <Typography variant="subtitle1" style={{ fontSize: 14, fontWeight: '500', color: '#ccc' }}>{heading}</Typography>
        </Grid>
        <Grid item xs={12}>
            <Typography variant="h6" style={{ color: '#333', padding: 10, border: '1px solid #ccc', fontSize: 14, borderRadius: 5, background: '#f0f0f0' }}>
                {subHeading}
            </Typography>
        </Grid>
    </Grid>;


    return (
        <PageTag>
            <BarTag title="Merchant Details" drawer={false} back={true} profile={false} dMode={false} />

            {loading ?
                <div style={{ height: '80vh' }}><CircularLoader opened={loading} /></div>
                :
                merchant &&
                <Container style={{ marginTop: 25 }}>
                    <Grid container spacing={2}>
                        <Grid item container xs={12}
                            direction="row"
                            justify="flex-end"
                            alignItems="flex-end">

                            <Button
                                style={{ color: !merchant.is_approved ? '#fff' : '#000', backgroundColor: !merchant.is_approved && colorPalette.primary }}
                                disabled={merchant.is_approved}
                                onClick={approveProfile}
                                variant={!merchant.is_approved ? "contained" : "text"}
                                startIcon={merchant.is_approved && <CheckCircleOutlineIcon style={{ color: !merchant.is_approved ? colorPalette.pending : colorPalette.success }} />}>
                                {!merchant.is_approved ? 'Approve Profile' : 'Approved'}
                            </Button>
                        </Grid>
                    </Grid>
                    <Paper className={classes.paper}>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={12} className="flexCenterColumn">
                                <div className={classes.imgContainer}>
                                    <div style={{ width: '100%', height: '100%', backgroundImage: `url(${merchant.profile_pic ? merchant.profile_pic : AVATAR})`, backgroundPosition: 'center', backgroundRepeat: 'no-repeat', backgroundSize: 'contain', borderRadius: 100, }} />
                                </div>

                            </Grid>
                            <Grid item xs={12} sm={6} style={{ marginTop: 65 }}>
                                <List>
                                    <ListSubheader disableSticky style={{ marginBottom: 20, display: 'flex' }}>
                                        <Typography variant={'h6'}>Merchant Profile</Typography>
                                        <Tooltip title="Update Merchant Profile">
                                            <IconButton
                                                component={Link}
                                                to={`/editMerchant?id=${merchant.id}`}
                                                style={{ marginTop: -5, alignSelf: 'center' }}
                                                variant="text">
                                                <Icon style={{ fontSize: 20 }}>edit</Icon>
                                            </IconButton>
                                        </Tooltip>
                                    </ListSubheader>
                                    <ListItem className={classes.listItem}>
                                        <Grid container spacing={1}>
                                            {renderProfileItem("First Name", merchant.first_name)}
                                            {renderProfileItem("Last Name", merchant.last_name)}
                                            {renderProfileItem("Company Name", merchant.company_name)}
                                            {renderProfileItem("Email", merchant.email)}
                                            {renderProfileItem("Operator", merchant.operator)}
                                            {renderProfileItem("Mobile", merchant.mobile)}
                                            {renderProfileItem("Business Type", merchant.business_type)}
                                            {renderProfileItem("Years In Business", merchant.no_of_years_in_buisness)}
                                            {renderProfileItem("Address", merchant.address, 12)}
                                        </Grid>
                                    </ListItem>
                                </List>
                            </Grid>
                            <Grid item xs={12} sm={6} style={{ marginTop: 70 }}>

                                <List>
                                    <ListSubheader disableSticky style={{ marginBottom: 40, marginLeft: -15 }}><Typography variant={'h6'}>Documents</Typography></ListSubheader>
                                    {!merchant.documents.length && <ListItem>
                                        <p style={{ fontStyle: 'italic' }}>* No documents uploaded.</p>
                                    </ListItem>}
                                    {merchant.documents.map((document, key) => {
                                        return <ListItem key={key} elevation={2} style={{ padding: 15, background: 'rgba(240, 240, 240, 0.6)', marginTop: 20, border: '1px solid #ccc', borderRadius: 5 }}>
                                            <ListItemIcon>
                                                <FolderIcon className={classes.folderIcon} />
                                            </ListItemIcon>
                                            <Typography noWrap={false} className={classes.docListHeading}>{documentTypes[document.doc_type]}</Typography>
                                            <ListItemSecondaryAction>
                                                <Tooltip title={!document.is_approved ? "Pending" : "Approved"}>
                                                    <span>
                                                        <Button
                                                            style={{ color: '#000' }}
                                                            disabled={document.is_approved}
                                                            variant={!document.is_approved ? "outlined" : "text"}
                                                            onClick={() => onDialogOpen(document)} startIcon={<CheckCircleOutlineIcon style={{ color: !document.is_approved ? colorPalette.pending : colorPalette.success }} />}>
                                                            {!document.is_approved && 'Approve'}
                                                        </Button>
                                                    </span>
                                                </Tooltip>

                                                <Tooltip title="Document Document">
                                                    <IconButton edge="end" aria-label="download" onClick={() => onDownload(document)}>
                                                        <CloudDownloadIcon className={classes.downloadIcon} />
                                                    </IconButton>
                                                </Tooltip>
                                            </ListItemSecondaryAction>

                                        </ListItem>
                                    })}
                                </List>
                            </Grid>
                        </Grid>
                    </Paper>
                </Container>
            }
            <div style={{ height: 20 }}></div>
        </PageTag>
    );
}

export default MerchantDetails;