import React, { useEffect, useState } from 'react';

import AiForm, { AiInput, AiSelect } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";
import { getMerchantStoreCategories, SignUpPwd } from "../../libs/apiProvider/apiProvider";
import { phoneValidate, validateEmail } from "appRoot/libs/helper";
import { connect } from 'unistore/react';
import { Button, Typography } from '@material-ui/core';
import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import { Link, Redirect, useHistory } from 'react-router-dom';
import Logo from '../../assets/logo.png';
import { removeDocumentSubmit } from '../../libs/sessionStorage/storageApis';
function SignUp({ isLoaded, token }) {
    if (!isLoaded) {
        return null;
    }

    const history = useHistory();
    const [loading, setLoading] = useState(false);
    const [categories, setCategories] = useState([]);
    
    const [isLoader, setIsLoader] = useState(false);
    const [isSignup, setIsSignUp] = useState(false);

    const [first_name, setFirstName] = useState('');
    const [last_name, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [company_name, setCompany_name] = useState('');
    const [address, setAddress] = useState('');
    const [operator, setOperator] = useState('');
    const [mobile, setMobile] = useState(0);
    const [businessType, setBusinessType] = useState('');
    const [yearsInBusiness, setYearsInBusiness] = useState('');
    const businessTypeArr = [{ value: 0, label: 'Store' }];


    useEffect(() => {
        getStoreCategories();
        if (token) {
            history.push('/');
        }
    }, []);


    const getStoreCategories = async () => {
        try {
            setLoading(true);

            const res = await getMerchantStoreCategories();
            if(!res.error && res.data.success) {
                const storeCategories = res.data.data.store_categories.map((category, index) => ({value: index, label: category}));
               setCategories(storeCategories);
            }
        }catch(e) {
            console.log("Error while getting categories", e);
        }

        setLoading(false);
    }

    const onSubmit = async (form) => {
        setIsLoader(true);
       
        if (first_name.length && last_name.length && validateEmail(email) && password.length >= 6 && company_name && address && operator && phoneValidate(mobile) && categories[businessType] && parseInt(yearsInBusiness) >= 0) {
            const data = {
                first_name,
                last_name,
                email,
                password,
                company_name,
                address,
                operator,
                mobile,
                business_type: categories[businessType].label,
                no_of_years_in_buisness: yearsInBusiness
            }
            try {
                const { success, message } = await SignUpPwd(data);
                if (success) {
                    setIsLoader(false);
                    setIsSignUp(true);
                    openComp({ compName: "snackbar", payload: { message, severity: 'success' } });
                    removeDocumentSubmit();
                }
            } catch (error) {
                const message = error.message || error;
                setIsLoader(false);
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            setIsLoader(false);
            openComp({ compName: "snackbar", payload: { message: 'Please fill all the fields.', severity: 'warning' } });
        }
    }

    if (isSignup) {
        return <Redirect to="/" />
    }

    return (
        <div className="w3-content">
            <div className="flexRow">
                <div className="flexItem w480">

                    <div className="w3-container">
                        <div className="w3-center" style={{ marginTop: 24, marginBottom: 4 }}>
                            <img alt="noola" src={Logo} className="inner2" />
                            <br />
                        </div>

                        <AiForm onDone={onSubmit} className="inner" style={{ color: "#127598" }}>

                            <Typography color="initial" style={{ marginTop: 5 }}>First Name</Typography>

                            <AiInput type="text"
                                autoComplete="text"
                                id={"first_name"}
                                value={first_name}
                                onChange={(e) => { setFirstName(e.target.value) }}
                                required
                            />

                            <Typography color="initial" style={{ marginTop: 5 }}>Last Name</Typography>

                            <AiInput type="text"
                                autoComplete="text"
                                id={"last_name"}
                                value={last_name}
                                onChange={(e) => { setLastName(e.target.value) }}
                                required
                            />

                            <Typography color="initial" style={{ color: "#127598" }}>Email</Typography>
                            <AiInput type="email" autoComplete="email" required
                                value={email}
                                // placeholder="Enter your email address"
                                onChange={(e) => { setEmail(e.target.value) }}
                                error={(email != '' && !validateEmail(email))}
                                helperText={(email && !validateEmail(email)) ? 'Email Invalid' : ''}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Password</Typography>
                            <AiInput
                                // placeholder="Enter you"    
                                // name="password" 
                                type="password"
                                autoComplete="current-password"
                                value={password}
                                onChange={(e) => { setPassword(e.target.value) }}
                                error={(password != '' && password.length < 6)}
                                helperText={(password && password.length < 6) ? 'Password should be equal or above 6 letters' : ''}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Company Name</Typography>

                            <AiInput type="text"
                                // name="company_name"
                                autoComplete="text"
                                id={company_name}
                                value={company_name}
                                onChange={(e) => { setCompany_name(e.target.value) }}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Address</Typography>

                            <AiInput
                                type="textarea"
                                // name="address" 
                                autoComplete="text"
                                value={address}
                                id="address"
                                onChange={(e) => { setAddress(e.target.value) }}
                                inputProps={{
                                    maxLength: 150
                                }}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Operator</Typography>
                            <AiInput type="text"
                                // name="operator" 
                                autoComplete="text"
                                id="operator"
                                value={operator}
                                onChange={(e) => { setOperator(e.target.value) }}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Mobile</Typography>
                            <AiInput type="tel"
                                // name="mobile"
                                value={mobile != '' ? mobile : ''}
                                onChange={(e) => { e.target.validity.valid && setMobile(e.target.value); }}
                                type="tel"
                                error={mobile != '' && !phoneValidate(mobile)}
                                helperText={mobile != '' && !phoneValidate(mobile) ? 'Phone number is invalid' : ''}
                                inputProps={{
                                    pattern: "[0-9]*",
                                    maxLength: 10
                                }}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Business Type</Typography>
                            <AiSelect
                                disabled={loading}
                                name="businessType" 
                                options={categories}
                                value={businessType}
                                onChange={({ target: { value } }) => { setBusinessType(value) }}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Years In Business</Typography>
                            <AiInput type="tel"
                                // name="yearsInBusiness"
                                value={yearsInBusiness}
                                id="yearsInBusiness"
                                onChange={(e) => { setYearsInBusiness(e.target.value) }}
                                error={yearsInBusiness < 0}
                                helperText={yearsInBusiness < 0 ? 'Min. 0' : ''}
                                inputProps={{
                                    pattern: "[0-9]*",
                                    maxLength: 4
                                }}
                            />
                            <div >
                                <div className="w3-center" style={{ marginTop: 24 }}>
                                    {!isLoader
                                        ? <Button fullWidth size="large" variant="contained" type="submit" style={{ color: "white", backgroundColor: "#127598" }}>Sign Up</Button>
                                        :
                                        <AiLoader color="secondary" opened={true} />
                                    }
                                </div>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}><p>Already have account?</p>
                                    <Link to="/login" className="w3-decoration w3-capsAll">
                                        <h4 style={{ color: "#127598", marginLeft: 5 }}>
                                            SIGN IN
                                    </h4>
                                    </Link>
                                </div>
                            </div>
                        </AiForm>
                    </div>

                </div>
            </div>
        </div>
    );
}



export default connect(store => ({
    isLoaded: store.auth.isLoaded,
    token: store.auth.fireUser
}))(SignUp);