import React, { useEffect, useState } from 'react';
import { connect } from "unistore/react";


//MAT-UI
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

//=+++=>AIUI 
import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import AiForm, { AiInput } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";

import { getProfile, getUser, forgotPassword } from "../../libs/apiProvider/apiProvider";
import { validateEmail } from "../../libs/helper";
import Logo from '../../assets/logo.png';
import { Link, useHistory, withRouter, Redirect } from 'react-router-dom';

const ForgotPassword = (props, isLoaded, token) => {
    if (!isLoaded) {
        return null;
    }
    const history = useHistory();
    useEffect(() => {
        if (token) {

        }
    }, []);
    const [isLoader, setIsLoader] = useState(false);
    const [isValid, setIsValid] = useState(false);

    const [email, setEmail] = useState('');

    const onSubmit = async (form) => {
        setIsLoader(true);

        if (validateEmail(email)) {
            const data = {
                email
            }
            try {
                const res = await forgotPassword(data);
                if (res.data.success) {

                    setIsLoader(false);
                    setIsValid(true);
                    openComp({ compName: "snackbar", payload: { message: res.data.message } });
                    history.push('/resetPassword');

                }
            } catch (error) {
                const message = error.message || error;
                setIsLoader(false);
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            setIsLoader(false);
            openComp({ compName: "snackbar", payload: { message: 'Please fill all the fields.', severity: 'warning' } });
        }
    }

    if (isValid) {
        return <Redirect to="/EnterOtp" />
    }



    return (
        <div className="w3-content">
            <div className="flexRow">
                <div className="flexItem w480">

                    <div className="w3-container">
                        <div className="w3-center" style={{ marginTop: 30 }}>
                            <img alt="noola" src={Logo} className="inner2" />
                            <br />
                        </div>

                        <AiForm onDone={onSubmit} className="inner">


                            <Typography color="inherit" style={{ color: "#127598" }}>Email</Typography>
                            <AiInput type="email" autoComplete="email" required
                                value={email}
                                onChange={(e) => { setEmail(e.target.value) }}
                                error={(email != '' && !validateEmail(email))}
                                helperText={(email && !validateEmail(email)) ? 'Email Invalid' : ''}
                            />



                            <div>
                                <div className="w3-center" style={{ marginTop: 24 }}>
                                    {!isLoader
                                        ? <Button fullWidth size="large" variant="contained" type="submit" style={{ color: "white", backgroundColor: "#127598" }}>Send otp</Button>
                                        :
                                        <AiLoader style={{ color: "#127598" }} opened={true} />
                                    }
                                </div>
                                <br />


                            </div>

                        </AiForm>

                    </div>

                </div>
            </div>
        </div>
    )
}



export default connect(store => ({
    isLoaded: store.auth.isLoaded,
    token: store.auth.fireUser
}))(withRouter(ForgotPassword));