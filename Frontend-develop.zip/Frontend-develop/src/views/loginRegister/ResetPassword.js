import React, { useEffect, useState } from 'react';
import { connect } from "unistore/react";


//MAT-UI
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

//=+++=>AIUI 
import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import AiForm, { AiInput } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";
import Logo from '../../assets/logo.png';
import { Link, useHistory, withRouter, Redirect } from 'react-router-dom';
import { resetPassword } from '../../libs/apiProvider/apiProvider';
import { removeToken } from '../../libs/sessionStorage/storageApis';

const ResetPassword = (isLoaded, token) => {
    if (!isLoaded) {
        return null;
    }
    const [isLoader, setIsLoader] = useState(false);
    const history = useHistory();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [otp, setOtp] = useState('');

    const onSubmit = async (form) => {
        if(password.toLowerCase() != confirmPassword.toLowerCase()) {
            openComp({ compName: "snackbar", payload: { message: "Password did not match", severity: 'error' } });
        }
        if (otp.length && password.length >= 6) {
            const data = {
                otp,
                password,
            }
            setIsLoader(true);
            try {
                const res = await resetPassword(data);
                setIsLoader(false);
                if(res.error) {
                    openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                }
                else {
                    if (res.data.success) {
                       
                        openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                        removeToken();
                        history.push('/');
                    }
                }
               
            } catch (error) {
                const message = error.message || error;
        
                setIsLoader(false);
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } else {
            setIsLoader(false);
            openComp({ compName: "snackbar", payload: { message: 'Please enter valid otp.', severity: 'warning' } });
        }
    }

    return (
        <div className="w3-content">
            <div className="flexRow">
                <div className="flexItem w480">

                    <div className="w3-container">
                        <div className="w3-center" style={{ marginTop: 30 }}>
                            <img alt="noola" src={Logo} className="inner2" />
                            <br />
                        </div>

                        <AiForm onDone={onSubmit} className="inner">



                            <Typography color="initial" style={{ marginTop: 5 }}>Enter OTP</Typography>
                            <AiInput type="tel"
                                value={otp}
                                id="otp"
                                onChange={(e) => { setOtp(e.target.value) }} />
                            <Typography color="initial" style={{ marginTop: 5 }}>Password</Typography>
                            <AiInput
                                type="password"
                                autoComplete="current-password"
                                value={password}
                                onChange={(e) => { setPassword(e.target.value) }}
                                error={(password != '' && password.length < 6)}
                                helperText={(password && password.length < 6) ? 'Password should be equal or above 6 letters' : ''}
                            />
                            <Typography color="initial" style={{ marginTop: 5 }}>Confirm Password</Typography>
                             <AiInput
                                type="password"
                                id="confirmPassword"
                                autoComplete="password"
                                value={confirmPassword}
                                onChange={(e) => { setConfirmPassword(e.target.value) }}
                                error={(confirmPassword != '' && confirmPassword.toLowerCase() != password.toLocaleLowerCase())}
                                helperText={(confirmPassword && confirmPassword.toLowerCase() != password.toLocaleLowerCase()) ? 'Password did not match' : ''}
                            />
                            <div>
                                <div className="w3-center" style={{ marginTop: 24 }}>
                                    {!isLoader
                                        ? <Button fullWidth size="large" variant="contained" type="submit" style={{ color: "white", backgroundColor: "#127598" }}>Change Password</Button>
                                        :
                                        <AiLoader style={{ color: "#127598" }} opened={true} />
                                    }
                                </div>
                                <br />


                            </div>

                        </AiForm>

                    </div>

                </div>
            </div>
        </div>
    )
}



export default connect(store => ({
    isLoaded: store.auth.isLoaded,
    token: store.auth.fireUser
}))(withRouter(ResetPassword));