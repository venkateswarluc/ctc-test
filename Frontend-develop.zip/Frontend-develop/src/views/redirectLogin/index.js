import React, { useState } from 'react';
import { connect } from "unistore/react";
import { Link } from "react-router-dom";

//MAT-UI
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

//=+++=>AIUI 
import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import AiForm, { AiInput } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";

import Logo from '../../assets/logo.png';

import { LoginWithPwd } from "appRoot/libs/apiProvider";

const Fpass = () => {

    const [number, setNumber] = useState('');
    const [isLoader, setIsLoader] = useState(false);


    return (
        <div className="w3-content">
            <div className="flexRow">
                <div className="flexItem w480">

                    <div className="w3-container">
                        <div className="w3-center" style={{ marginTop: 24, marginBottom: 4 }}>
                            <img alt="noola" src={Logo} className="inner2" />
                            <br />
                        </div>

                        <AiForm className="inner">
                            <Typography color="inherit" component={Button}>Thank You </Typography>
                          
                          



                            <div className="w3-panel">
                                <div className="w3-center" style={{ marginTop: 24 }}>
                                    {
                                        <Button size="large" variant="contained" color="primary" type="submit" style={{ minWidth: 154 }}> <Link to=""style={{textDecoration:"none"}}>
                                           
                                                Login
                    
                                        </Link></Button>

                                    }
                                </div>
                            </div>

                        </AiForm>

                    </div>

                </div>
            </div>
        </div>
    )
}



export default Fpass;