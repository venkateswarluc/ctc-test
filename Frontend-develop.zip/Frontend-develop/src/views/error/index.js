import React from "react";
import { Link, useLocation } from "react-router-dom";

//MAT-UI 
import Typography from '@material-ui/core/Typography';
import Icon from '@material-ui/core/Icon';
import Button from '@material-ui/core/Button';


const ErrorView = () => {
  let location = useLocation();
  return (
    <div className="w3-content w3-center">
      <div className="w3-container w3-margin-sm">
        <Typography variant="h3" gutterBottom>Error 404</Typography>

        <Icon color="secondary" style={{ fontSize: 64 }}>error</Icon>

        <div className="w3-panel">
          <Typography variant="overline">Looks like we hit a snag</Typography>
          <Typography variant="subtitle2" gutterBottom>{location.pathname}</Typography>
        </div>

        <div className="w3-container w3-margin-sm">
          <Button variant="outlined" color="inherit" to="/" component={Link} startIcon={<Icon>dashboard</Icon>}>
            Dashboard
          </Button>
        </div>

      </div>
    </div>
  )
}


export default ErrorView;