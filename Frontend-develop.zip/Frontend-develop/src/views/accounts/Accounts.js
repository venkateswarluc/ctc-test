import React, { useState, useCallback, useEffect, Fragment, useRef } from 'react';
import { usePlaidLink } from 'react-plaid-link';
import PlaidLink from "react-plaid-link";
import AiForm, { AiInput, AiSelect } from 'appRoot/components/AiForm';
import AiLoader from "appRoot/components/AiLoader";
import Container from '@material-ui/core/Container'
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';


import { connect } from 'unistore/react';

import { openComp, setAuth } from "appRoot/uniStore/StateMgr";
import { Link, useHistory } from 'react-router-dom';
import BarTag from "appRoot/tags/BarTag";
import PageTag from "appRoot/tags/PageTag";
import { addFundToAccount, createPlaidLinkToken, getMyBanks, makeAccountDefault, registerBankAccount, unlinkBankAccount, addFundToBankAccount,  } from '../../libs/apiProvider/bankAPI';
import useStyles, { colorPalette } from '../../libs/styleProvider';
import CircularLoader from '../../components/AiCircularLoader';
import CustomTable from '../../components/AiCustomTable/CustomTable';
import { customObject, NumberFormatCustom, numberWithCommas } from '../../libs/helper';
import TableButton from '../../components/AiCustomTable/Button';
import Accordian from '../../components/AiAccordian/Accordian';

import { Button, InputAdornment, makeStyles, Typography } from '@material-ui/core';
import { resetComp, setAccordianExpanded } from '../../uniStore/StateMgr';
import { getProfile } from '../../libs/apiProvider/apiProvider';

const Scroll = require('react-scroll');

const BORDER_RADIUS = 15;
const BOX_SHADOW = '10px 10px 15px 0px rgba(0,0,0,0.1)';
const CARD_ELEVATION = 0;
const useAccountStyles = makeStyles((theme) => ({
    card: {
        minHeight: 260,
        borderRadius: BORDER_RADIUS,
        boxShadow: BOX_SHADOW
    },
    walletheading: {
        textAlign: 'center',
        [theme.breakpoints.down('sm')]: {
            fontSize: 12
        },
        [theme.breakpoints.down('xs')]: {
            fontSize: '1.25rem'
        }
    },
    bankHeadingContainer: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            alignItems: 'flex-end'
        },
    },
    bankName: {
        fontSize: 14,
        [theme.breakpoints.down('sm')]: {
            fontSize: 12
        },
        [theme.breakpoints.down('xs')]: {
            fontSize: 10,
        }
    },
    balance: {
        fontSize: 14,
        [theme.breakpoints.down('sm')]: {
            marginTop: 50,
            fontSize: 10,
        },
        textAlign: 'left',
        position: 'absolute',
        marginTop: -22,
        letterSpacing: .5,
        fontWeight: '500'
    },
    button: {

        [theme.breakpoints.down('sm')]: {
            fontSize: 10,
        },
        [theme.breakpoints.down('xs')]: {
            fontSize: '0.875rem !important',
        },
    }
}));

function Accounts(props) {
    const { isLoaded, token } = props;
    const classes = useStyles();
    const accountStyles = useAccountStyles();
    const bankListRef = useRef(null);
    if (!isLoaded) {
        return null;
    }
    const [tableLoading, setTableLoading] = useState(false);
    const [noBank, setNoBank] = useState('');
    const history = useHistory();
    const [addMoney, setAddMoney] = useState('');
    const [limit, setLimit] = useState(0);
    const [tableData, setTableData] = useState([]);
    const [defaultAccount, setDefaultAccount] = useState(null);
    const [user, setUser] = useState(null);

    const [addBankMoney, setAddBankMoney] = useState('');
    const onExit = useCallback(
        (err, metadata) => {
            if (err && err.error_code === "INVALID_LINK_TOKEN") {
                createPlaidLink();
            }
            console.log('onExit', metadata)
        },
        []
    );

    const onSuccess = useCallback((public_token, metadata) => {
        const bankData = {
            "public_token": public_token,
            "institution_id": metadata.institution.institution_id,
            "institution_name": metadata.institution.name,
            "account_id": metadata.account.id,
            "account_name": metadata.account.name,
            "account_type": metadata.account.type,
            "account_subtype": metadata.account.subtype,
            "account_mask": metadata.account.mask
        };

        registerBank(bankData).then(() => {
            getBanks();
        })
    }, []);

    const [plaidConfig, setPlaidConfig] = useState({
        token: "",
        publicKey: token,
        env: "sandbox",
        onSuccess,
        onExit,
    });


    useEffect(() => {
        getUser();
        createPlaidLink();
        getBanks();
    }, []);

    const getUser = async () => {
        try {
            const res = await getProfile();
            setUser(res);
        } catch (e) {
            console.log(e);
        }
    }
    const getBanks = async () => {
        setTableLoading(true);
       try {
        const res = await getMyBanks();
        if (res.error) {
            setNoBank('Sorry! You dont have any bank account linked with Noola yet.');
            setDefaultAccount(null);
            setTableLoading(false);
            return;
        }
        if (res.data.success) {

            const accounts = [];
            res.data.data.customer_accounts.map(account => {
                if (account.is_default) {
                    accounts.unshift(account);
                    setDefaultAccount(account);
                }
                if (!account.is_default) {
                    accounts.push(account);
                }
            });
            setTableData(accounts);
            setNoBank('');
        }
        setTableLoading(false);
       }catch(e) {
        setNoBank(e.message);
        setDefaultAccount(null);
        setTableLoading(false);
       }
    }
    const { open, ready, error } = usePlaidLink(plaidConfig);
    const createPlaidLink = async () => {
        try {
            const res = await createPlaidLinkToken();
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            const { data, success, message } = res.data;
            if (success) {
                const config = {
                    token: data.link_token,
                    publicKey: token,
                    env: "sandbox",
                    onSuccess,
                    onExit,
                };
                setPlaidConfig(config);

            } else {
                openComp({ compName: "snackbar", payload: { message, severity: 'error' } });
            }
        } catch (e) {
            console.log("error occured:- ", e);
        }
    }

    const registerBank = async (bankData) => {
        try {
            const res = await registerBankAccount(bankData);
        } catch (e) {
            console.log("Error occurred while adding bank", e);
        }
    }

    const unlinkBank = async (id) => {
        try {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            const res = await unlinkBankAccount({ "customer_account_id": id });
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            resetComp({ compName: "dialog" });
            if (res.data.success) {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                getBanks();
            } else {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'error' } });
            }
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: "Error Occurred.", severity: 'error' } });
        }
    }

    const onAccountDefault = async (id) => {
        try {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });

            const res = await makeAccountDefault({ customer_account_id: id });
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }
            resetComp({ compName: "dialog" });
            if (res.data.success) {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                getBanks();
            } else {
                openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'error' } });
            }
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: "Error Occurred.", severity: 'error' } });
        }
    }
    const openDialog = (id, title, children, message, fun) => {
        openComp({
            compName: 'dialog',
            payload: {
                opened: true,
                title,
                warning: <span style={{ fontStyle: 'italic' }}>{message}</span>,
                children,
                onDone: async (isOk) => {
                    if (isOk) {
                        fun(id);
                    } else {
                        resetComp({ compName: "dialog" });
                    }
                }
            }
        });

    }
    const onAddFundsToWallet = async () => {
        if (defaultAccount === null) {
            openComp({ compName: "snackbar", payload: { message: 'Please add Bank to add money to wallet.', severity: 'error' } });
        }
        if (defaultAccount && addMoney && parseInt(addMoney) > 0) {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            try {
                const res = await addFundToAccount({
                    source_account_id: defaultAccount.id,
                    amount: addMoney
                });
                resetComp({ compName: "dialog" });
                setAddMoney('');

                if (res.error) {
                    openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                    return;
                }
                if (res.data.success) {
                    
                    openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                    getUser();
                }
            } catch (e) {
                openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
            }
        }
    }


    const onAddFundsToBank = async () => {
        if (defaultAccount && addBankMoney && parseInt(addBankMoney) > 0) {
            openComp({
                compName: 'dialog',
                payload: {
                    loading: true,
                    children: <CircularLoader opened={true} size={20} />
                }
            });
            try {
                const res = await addFundToBankAccount({
                    source_account_id: defaultAccount.id,
                    amount: addBankMoney
                });
                resetComp({ compName: "dialog" });
                setAddBankMoney('');

                if (res.error) {
                    openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                    return;
                }
                if (res.data.success) {
                    openComp({ compName: "snackbar", payload: { message: res.data.message, severity: 'success' } });
                    getUser();
                }
            } catch (e) {
                openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
            }
        }
    }


    const renderTableButtons = (item) => {
        return [
            <div style={{ justifyContent: 'space-between', display: 'flex', maxWidth: 290 }}>
                <TableButton
                    disabled={defaultAccount && defaultAccount.id === item.id}
                    btnType="primary"
                    style={{ minWidth: 106 }}
                    onClick={() => openDialog(item.id, "Make Default", "Make Default", `*Do you want to make ${item.institution_name.toUpperCase()} default?`, onAccountDefault)}>
                    {(defaultAccount && defaultAccount.id === item.id) ? 'Default' : 'Make Default'}
                </TableButton>
                <TableButton btnType="success" component={Link} to={`/merchantTransactions?transaction_source=${item.institution_name}&transaction_type=ALL`}>
                    transactions
                </TableButton>
                <TableButton btnType="danger" onClick={() => openDialog(item.id, "Delete Bank", 'Delete', `*Do you want to Delete ${item.institution_name.toUpperCase()}?`, unlinkBank)}>
                    Delete
                </TableButton>
            </div >
        ];
    }




    const walletAmount = () => <Typography variant="subtitle1"
        className={accountStyles.balance}>
        Wallet Balance <br></br>
        <span style={{ fontWeight: '500' }}>
            ${user ? numberWithCommas(user.wallet_total_balance) : "0.00"}
        </span>
    </Typography>
    return (
        <PageTag>
            <BarTag title="Accounts" drawer={true} profile={true} dMode={false} />
            <Container style={{ marginTop: 25 }} >
                {/* <Typography variant="subtitle1" style={{textAlign: 'right', marginBottom: 15, fontWeight: '700' }}>Wallet Balance <span style={{fontWeight: '500'}}>${user ? numberWithCommas(user.wallet_total_balance) : "0.00"}</span></Typography> */}
                <Grid container spacing={3}>
                    {/* <Grid item xs={12} sm={4}>
                        <Paper elevation={CARD_ELEVATION} className={`${classes.flexVertical} ${accountStyles.card}`} style={{ padding: 50 }}>
                            <div>

                            </div>
                        </Paper>
                    </Grid> */}

                    <Grid item xs={12} sm={4}>
                        <Paper elevation={CARD_ELEVATION} className={`${classes.flexVertical} ${accountStyles.card}`} style={{ padding: 50 }}>
                            <Typography variant="h6">Link Bank Account</Typography>
                            <Button disableElevation onClick={() => open()} disabled={!ready} variant="contained" style={{ minWidth: 140 }} className={classes.button}>
                                {ready ? "link Account" : <CircularLoader color="inherit" opened={true} size={20} />}
                            </Button>
                        </Paper>
                    </Grid>

                    <Grid item xs={12} sm={4}>
                        <Paper elevation={CARD_ELEVATION} className={accountStyles.card} style={{ padding: 25, display: 'flex', flexDirection: 'column', justifyContent: 'space-evenly' }}>
                            <Typography className={accountStyles.walletheading} variant="h6">Add Money To Noola Wallet</Typography>
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={8}>
                                    <AiInput
                                        type="tel"
                                        value={addMoney != '' ? addMoney : ''}
                                        onChange={e => setAddMoney(e.target.value)}
                                        error={addMoney < 0}
                                        helperText={addMoney < 0 ? 'Please enter valid amount' : ''}
                                        id="formatted-numberformat-input"
                                        InputProps={{
                                            inputComponent: NumberFormatCustom,
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </Grid>
                                <Grid item container xs={12} sm={4}
                                    justify="center"
                                    alignItems="center">
                                    <Button
                                        style={{ marginTop: 6 }}
                                        disabled={addMoney == '' || parseInt(addMoney) <= 0}
                                        fullWidth
                                        disableElevation
                                        variant="contained"
                                        onClick={() => {
                                            if (defaultAccount === null) {
                                                openComp({ compName: "snackbar", payload: { message: 'Please add Bank to add money to Noola Wallet.', severity: 'error' } });
                                                setAddMoney('');
                                                return;
                                            }
                                            openDialog('', "Add Money To Wallet", "Add",
                                            <div>
                                                <Typography variant="subtitle1">Bank Name:- {defaultAccount.institution_name}</Typography>
                                                <Typography variant="subtitle1">Bank Account:- {defaultAccount.account_name}</Typography>
                                                <Typography variant="subtitle1">Add Money:- ${numberWithCommas(addMoney)}</Typography>
                                                
                                            </div>, onAddFundsToWallet);
                                            }}
                                        className={classes.button}
                                    >
                                        {"Add"}
                                    </Button>
                                </Grid>
                            </Grid>
                                <div style={{ textAlign: 'right', marginTop: 12 }}>
                                   { defaultAccount && <div className={accountStyles.bankHeadingContainer}>
                                        <Typography className={accountStyles.bankName} variant="h6" style={{ marginRight: 2 }}>{defaultAccount.institution_name} </Typography>
                                        <Typography variant="caption"> (default)</Typography>
                                    </div>}
                                    {walletAmount()}
                                   { defaultAccount && <div>
                                        <Typography variant="caption">{defaultAccount.account_name}</Typography>
                                        <br></br>
                                        <Typography variant="caption">*******{defaultAccount.account_mask}</Typography>
                                        <br></br>
                                        <Button
                                            variant="text"
                                            disableTouchRipple
                                            onClick={() => Scroll.animateScroll.scrollTo(bankListRef.current.offsetTop)}
                                            style={{ textTransform: 'none', marginRight: -8, color: colorPalette.primary }}>Change</Button>
                                    </div>}


                                </div>

                        </Paper>

                    </Grid>
                    <Grid item xs={12} sm={4}>
                        <Paper elevation={CARD_ELEVATION} className={accountStyles.card} style={{ padding: 25, display: 'flex', flexDirection: 'column', justifyContent: 'space-evenly' }}>
                            <Typography className={accountStyles.walletheading} variant="h6">Transfer Money To  Bank Account</Typography>
                            <Grid container spacing={2}>
                                <Grid item xs={12} sm={8}>
                                    <AiInput
                                        type="tel"
                                        value={addBankMoney != '' ? addBankMoney : ''}
                                        onChange={e => setAddBankMoney(e.target.value)}
                                        error={addBankMoney < 0}
                                        helperText={addBankMoney < 0 ? 'Please enter valid amount' : ''}
                                        id="formatted-numberformat-input transfer"
                                        InputProps={{
                                            inputComponent: NumberFormatCustom,
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </Grid>
                                <Grid item container xs={12} sm={4}
                                    justify="center"
                                    alignItems="center">
                                    <Button
                                        style={{ marginTop: 6 }}
                                        disabled={addBankMoney == '' || parseInt(addBankMoney) <= 0}
                                        fullWidth
                                        disableElevation
                                        variant="contained"
                                        onClick={() => {
                                            if (defaultAccount === null) {
                                                openComp({ compName: "snackbar", payload: { message: 'Please add Bank to transfer money to Bank Account.', severity: 'error' } });
                                                setAddBankMoney('');
                                                return;
                                            }
                                            openDialog('', "Transfer Money", "Transfer",
                                            <div>
                                                <Typography variant="subtitle1">Bank Name:- {defaultAccount.institution_name}</Typography>
                                                <Typography variant="subtitle1">Bank Account:- {defaultAccount.account_name}</Typography>
                                                <Typography variant="subtitle1">Transfer Money:- ${numberWithCommas(addBankMoney)}</Typography>
                                                
                                            </div>, onAddFundsToBank)
                                        }}
                                        className={classes.button + ' ' + accountStyles.button}
                                    >
                                        Transfer
                                    </Button>
                                </Grid>
                            </Grid>
                                <div style={{ textAlign: 'right', marginTop: 12 }}>
                                    {defaultAccount && <div className={accountStyles.bankHeadingContainer}>
                                        <Typography className={accountStyles.bankName} variant="h6" style={{ marginRight: 2 }}>{defaultAccount.institution_name} </Typography>
                                        <Typography variant="caption"> (default)</Typography>
                                    </div>}
                                    {walletAmount()}
                                   {defaultAccount &&  <div>
                                        <Typography variant="caption">{defaultAccount.account_name}</Typography>
                                        <br></br>
                                        <Typography variant="caption">*******{defaultAccount.account_mask}</Typography>
                                        <br></br>
                                        <Button
                                            variant="text"
                                            disableTouchRipple
                                            onClick={() => Scroll.animateScroll.scrollTo(bankListRef.current.offsetTop)}
                                            style={{ textTransform: 'none', marginRight: -8, color: colorPalette.primary }}>Change</Button>
                                    </div>}
                                </div>

                        </Paper>

                    </Grid>
                    <Grid item xs={12} ref={bankListRef}>
                        {tableLoading
                            ?
                            <CircularLoader opened={true} size={30} />
                            :
                            (
                                noBank
                                    ?
                                    <Paper elevation={CARD_ELEVATION} style={{ borderRadius: BORDER_RADIUS, boxShadow: BOX_SHADOW, height: '50px !important', padding: 25, textAlign: 'center' }}><p style={{ fontStyle: 'italic' }}>{noBank}</p></Paper>
                                    :
                                    <CustomTable
                                        style={{
                                            borderRadius: BORDER_RADIUS,
                                            boxShadow: BOX_SHADOW
                                        }}
                                        // ID names should match with object of data
                                        tableHead={[
                                            { id: "institution_name", label: "Institution Name" },
                                            { id: 'account_name', label: 'Account Name' },
                                            { id: "actions", label: 'Actions' }
                                        ]}
                                        data={customObject(tableData, ['institution_name', 'account_name', 'id'])}
                                        extraRows={renderTableButtons}
                                    >
                                    </CustomTable>
                            )
                        }
                    </Grid>
                </Grid>
            </Container>
        </PageTag>
    );
}

export default connect(store => ({
    isLoaded: store.auth.isLoaded,
    token: store.auth.fireUser
}))(Accounts);