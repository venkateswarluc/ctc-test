import React, { useEffect, useState, memo, useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import { connect } from "unistore/react";

import { makeStyles } from '@material-ui/core/styles';


//AIUI 
import PageTag from "appRoot/tags/PageTag";
import BarTag from 'appRoot/tags/BarTag';

import { Button, Container, Fab, Grid, Icon, IconButton, List, ListItem, ListSubheader, Paper, TableContainer, Tooltip, Typography, useMediaQuery, useTheme } from "@material-ui/core";
import GroupAddIcon from '@material-ui/icons/GroupAdd';
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';

import useDefaultStyles, { BORDER_RADIUS, BOX_SHADOW, CARD_ELEVATION, colorPalette } from '../../libs/styleProvider';
import Line from '../../components/Graphs/Line';
import Doughnut from '../../components/Graphs/Area';
import CircularLoader from '../../components/AiCircularLoader';
import { getAllMerchants } from "../../libs/apiProvider/adminApi";
import { openComp } from "../../uniStore/StateMgr";
import { months } from "../../libs/helper";
import Select from '../../components/AiForm/AiSelect';
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import UpdateIcon from '@material-ui/icons/Update';
import AVATAR from '../../assets/avatar.jpg';

const useStyles = makeStyles((theme) => ({
    paper: {
        minHeight: 350,
        borderRadius: BORDER_RADIUS,
        boxShadow: BOX_SHADOW,
        padding: 20,
    },
    buttonContainer: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    heading: {
        marginTop: 1,
        fontSize: 13,
        fontWeight: '700'
    },
    subHeading: {
        fontWeight: '300',
        fontSize: 10
    },
    listItem: {
        justifyContent: 'space-between',

    }
}));


const AdminDashboard = ({ fireUser }) => {
    const classes = useStyles();
    const defaultStyles = useDefaultStyles();
    const mediaQuery = useMediaQuery('(max-width:800px)');
    const [loader, setLoader] = useState(false);

    // Merchant States
    const [merchants, setMerchants] = useState([]);
    const [showMerchants, setShowMerchants] = useState([]);
    const [merchantLabels, setMerchantLabels] = useState([]);
    const [totalMerchants, setTotalMerchants] = useState(0);
    const [merchantYears, setMerchantYears] = useState([]);
    const [selectMerchantYear, setSelectMerchantYear] = useState('');
    const [merchantStatus, setMerchantStatus] = useState([]);
    const [latestMerchants, setLatestMerchants] = useState([]);

    useEffect(() => {
        fetchAllMerchants();
        fetchAllUsers();
    }, []);
    const fetchAllMerchants = useCallback(async () => {
        try {
            setLoader(true);
            const { data } = await getAllMerchants();
            if (data.success) {
                let merchantCountObject = {};
                let approve = 0;
                let pending = 0;

                data.data.merchants.map((merchant, i) => {
                    if (merchant.is_approved) {
                        approve += 1;
                    } else {
                        pending += 1;
                    }
                    const date = merchant.created_at.split('T')[0].split('-');
                    merchantCountObject[`${date[0]}-${date[1]}`] = (merchantCountObject[`${date[0]}-${date[1]}`] || 0) + 1;
                });

                setMerchantStatus([approve, pending]);
                // merchantCountObject['2021-06'] = 41;
                // merchantCountObject['2021-07'] = 45;
                // merchantCountObject['2021-08'] = 22;
                // merchantCountObject['2021-09'] = 84;
                // merchantCountObject['2021-10'] = 104;
                // merchantCountObject['2021-11'] = 64;
                // merchantCountObject['2021-12'] = 74;
                // merchantCountObject['2022-04'] = 26;
                // merchantCountObject['2022-06'] = 28;
                // merchantCountObject['2022-08'] = 31;
                // merchantCountObject['2022-10'] = 24;
                // merchantCountObject['2022-12'] = 34;
                const years = [];
                const merchants = Object.entries(merchantCountObject).map((obj, index) => {
                    if (!years.some(year => year.label === obj[0].split('-')[0])) {
                        years.push({ value: index, label: obj[0].split('-')[0] });
                    }
                    return obj;
                });
                const showMerchants = [];
                const labels = [];
                Object.entries(merchantCountObject).filter(obj => {
                    if (years[0].label === obj[0].split('-')[0]) {
                        showMerchants.push(obj[1]);
                        labels.push(months[obj[0].split('-')[1]]);
                    }
                });
                // console.log(labels);
                let totalMerchant = 0;
                merchants.map(merchant => totalMerchant += merchant[1]);
                setLatestMerchants(data.data.merchants.reverse().slice(0, 5));
                setTotalMerchants(totalMerchant);
                setMerchants(merchants);
                setMerchantLabels(labels);
                setMerchantYears(years);
                setShowMerchants(showMerchants);
                setSelectMerchantYear(years[0].value);
            }
            setLoader(false);
        } catch (e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
        }
    }, []);


    const fetchAllUsers = () => {

    }


    const onMerchantYearChange = (value) => {
        setSelectMerchantYear(value);
        const year = merchantYears.filter(year => year.value === value)[0];
        const merchantsByYear = merchants.filter(merchant => merchant[0].split('-')[0] === year.label);
        const showMerchants = [];
        const labels = [];
        merchantsByYear.filter(obj => {
            if (year.label === obj[0].split('-')[0]) {
                showMerchants.push(obj[1]);
                labels.push(months[obj[0].split('-')[1]]);
            }
        });
        setShowMerchants(showMerchants);
        setMerchantLabels(labels);
    }

    const renderLatestMerchantList = useMemo(() => <List>
        <ListSubheader disableSticky style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0px 12px 20px 0px rgba(0,0,0,0.019)' }}>
            <Typography variant="body2">Latest Merchants</Typography>
            <Button
                component={Link}
                to={'/merchantList'}
                variant="text"
                style={{ fontSize: 12 }}>View All</Button>
        </ListSubheader>
        {latestMerchants.map(merchant => {
            return <ListItem key={merchant.id} className={classes.listItem}>
                <Grid container spacing={1} style={{ display: 'flex', alignItems: 'center' }}>
                    <Grid item xs={1}>
                        <img style={{ width: mediaQuery ? 20 : 35, height: mediaQuery ? 20 : 35, objectFit: 'contain', border: '0.4px solid #ccc', borderRadius: 100 }} src={merchant.profile_pic || AVATAR} />
                    </Grid>
                    <Grid item xs={9} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <div style={{ width: mediaQuery ? '50%' : '20%', wordWrap: 'break-word' }}>
                            <Typography variant="subtitle1" className={classes.heading}>{merchant.company_name}</Typography>
                            <Typography variant="body2" className={classes.subHeading}>{merchant.email}</Typography>
                        </div>
                        {!mediaQuery && <div style={{ width: '30%', wordWrap: 'break-word', display: 'flex', justifyContent: 'space-between', }}>
                            <Typography variant="subtitle1" className={classes.heading}>{merchant.address}</Typography>
                            <Typography variant="subtitle1" className={classes.heading}>{merchant.mobile}</Typography>
                        </div>}

                        {merchant.is_approved ? <Tooltip title="Approved">
                            <CheckCircleOutlineIcon style={{ color: colorPalette.success, fontSize: mediaQuery ? 20 : 25 }} />
                        </Tooltip> : <Tooltip title="Pending">
                            <UpdateIcon style={{ color: colorPalette.pending, fontSize: mediaQuery ? 20 : 25 }} />
                        </Tooltip>}
                        <Typography variant="body2" className={classes.subHeading} style={{ marginLeft: 5 }}>{merchant.created_at.split('T')[0]}</Typography>

                    </Grid>



                    <Grid item xs={2} style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                        <Button
                            disableRipple
                            component={Link}
                            to={`/merchantDetails?id=${merchant.id}`}
                            variant="text"
                            style={{ fontSize: 12, color: '#878787' }}>View</Button>
                    </Grid>
                </Grid>
            </ListItem>
        })}
    </List>, [latestMerchants, classes]);

    const renderDoughnatChart = useMemo(() => <Doughnut
        labels={['Approved', 'Pending']}
        data={merchantStatus}
    />, [merchantStatus]);

    const renderMerchantLineGraph = useMemo(() => <Line
        title={'Merchants Onboard'}
        labels={merchantLabels}
        height={mediaQuery ? 220 : 210}
        colors={["#1f70f2"]}
        data={[{ data: showMerchants, name: "Merchants Onboarded" }]} />, [showMerchants, merchantLabels, loader]);
    return (
        <PageTag>
            <BarTag title="Dashboard" drawer={true} profile={true} dMode={false} />
            {loader ? <CircularLoader opened={true} />
                :
                <Container style={{ marginTop: -30 }}>
                    <Grid container item spacing={2}>
                        <Grid item xs={12} sm={6}>
                            <Paper elevation={CARD_ELEVATION} className={classes.paper}>
                                <div className={classes.buttonContainer}>
                                    <Tooltip title="Add Merchant">
                                        <IconButton
                                            component={Link}
                                            to={'/registerMerchant'}
                                            size="small"
                                            style={{ background: colorPalette.primary, boxShadow: BOX_SHADOW, color: '#fff', padding: 10, fontSize: 9}}
                                            className={defaultStyles.button}>
                                            <GroupAddIcon style={{ fontSize: 20 }} />
                                        </IconButton>
                                    </Tooltip>
                                    <div style={{ textAlign: 'right' }}>
                                        <Typography variant="caption">Merchants Onboarded</Typography>
                                        <Typography variant="subtitle2">{totalMerchants}</Typography>
                                        <Select
                                            style={{ height: 30, width: 100, marginLeft: 20 }}
                                            name="merchantYear"
                                            options={merchantYears}
                                            onChange={({ target: { value } }) => onMerchantYearChange(value)}
                                            value={selectMerchantYear}
                                        />
                                    </div>
                                </div>
                                <div>
                                    {renderMerchantLineGraph}
                                </div>
                            </Paper>
                        </Grid>



                        <Grid item xs={12} sm={6}>
                            <Paper elevation={CARD_ELEVATION} className={classes.paper}>
                                <div className={classes.buttonContainer}>
                                    <Tooltip title="All Merchants">
                                        <IconButton
                                            component={Link}
                                            to={'/merchantList'}
                                            size="small"
                                            style={{ background: colorPalette.primary, boxShadow: BOX_SHADOW, color: '#fff', padding: 10, fontSize: 9 }}
                                            className={defaultStyles.button}>
                                            <Icon style={{ fontSize: 20 }}>{'storefront'}</Icon>
                                        </IconButton>
                                    </Tooltip>
                                    <div style={{ textAlign: 'right' }}>
                                        <Typography variant="caption">Merchants Onboarded</Typography>
                                        <Typography variant="subtitle2">{totalMerchants}</Typography>
                                        <div></div>
                                    </div>

                                </div>
                                <div style={{ height: 280 }}>
                                    {renderDoughnatChart}
                                </div>
                            </Paper>
                        </Grid>
                        <Grid item xs={12}>
                            <Paper elevation={CARD_ELEVATION} className={classes.paper} style={{ padding: 0 }}>
                                {renderLatestMerchantList}
                            </Paper>
                        </Grid>
                    </Grid>
                </Container>
            }

        </PageTag>
    )
};

export default connect(store => ({
    fireUser: store.auth.fireUser
}))(AdminDashboard)