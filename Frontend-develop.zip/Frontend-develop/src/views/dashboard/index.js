import React, { useEffect, useState } from 'react';
import { connect } from 'unistore/react';
import AiCircularLoader from '../../components/AiCircularLoader';
import jwt_decode from "jwt-decode";
import { useHistory } from 'react-router';
import PageTag from '../../tags/PageTag';
import BarTag from '../../tags/BarTag';
import AdminDashboard from './AdminDashboard';
import MerchantDashboard from './MerchantDashboard';
function Dashboard({ token }) {
    const [scope, setScope] = useState(null);
    const history = useHistory();
    useEffect(() => {
        if (token) {
            const decodeData = jwt_decode(token);
            if ('scope' in decodeData) {
                setScope(decodeData.scope);
            }
        } else {
            history.push('/login');
        }
    }, []);

    return (

        <PageTag >
            <BarTag title="Dashboard" />

            {scope === 'admin'
                ?
                <AdminDashboard />
                :
                scope === 'merchant'
                    ?
                    <MerchantDashboard />
                    :
                    <div style={{ height: '100vh' }}>
                        <AiCircularLoader opened={true} />
                    </div>}
        </PageTag>

    );
}

const mapStateToProps = state => ({
    token: state.auth.fireUser
});
export default connect(mapStateToProps)(Dashboard);