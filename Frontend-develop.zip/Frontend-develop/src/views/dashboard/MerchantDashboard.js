import React, { createRef, Fragment, useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { connect } from "unistore/react";



//AIUI 
import PageTag from "appRoot/tags/PageTag";
import BarTag from 'appRoot/tags/BarTag';
import { openComp } from "../../uniStore/StateMgr";
import { getMyBanks, getWalletTransactions } from "../../libs/apiProvider/bankAPI";
import { kFormatter, months, NumberFormatCustom, numberWithCommas } from "../../libs/helper";
import { Button, Container, Fab, Grid, Icon, IconButton, InputAdornment, List, ListItem, ListSubheader, makeStyles, Paper, Tooltip, Typography, useMediaQuery } from "@material-ui/core";
import useDefaultStyles, { BORDER_RADIUS, BOX_SHADOW, CARD_ELEVATION, colorPalette } from "../../libs/styleProvider";
import CircularLoader from '../../components/AiCircularLoader';
import Select from '../../components/AiForm/AiSelect';
import Input from '../../components/AiForm/AiInput';
import AreaGraph from "../../components/Graphs/Area";
import MultiLine from "../../components/Graphs/MultiLine";
import AccountBalanceWalletIcon from '@material-ui/icons/AccountBalanceWallet';
import MultiBar from "../../components/Graphs/MultiBar";
import { FcSimCardChip } from 'react-icons/fc';
import { getProfile, updateMerchantProfile } from "../../libs/apiProvider/apiProvider";
import CheckCircleOutlineIcon from '@material-ui/icons/CheckCircleOutline';
import UpdateIcon from '@material-ui/icons/Update';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
const useStyles = makeStyles((theme) => ({
    paper: {
        minHeight: 350,
        [theme.breakpoints.down('xs')]: {
            minHeight: 320
        },
        borderRadius: BORDER_RADIUS,
        boxShadow: BOX_SHADOW,
        padding: 20
    },
    buttonContainer: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    heading: {
        marginTop: 1,
        fontSize: 15,
        [theme.breakpoints.down('xs')]: {
            fontSize: 8
        },
        fontWeight: '700'
    },
    bankCard: {
        padding: 20,
        minHeight: '180px',
        borderRadius: BORDER_RADIUS,
        boxShadow: '0px 18px 25px 0px rgba(216, 59, 196, 0.25), 12px 20px 35px 0px rgba(92, 149, 199, 0.15)',
        backgroundImage: 'linear-gradient(135deg, rgba(216, 59, 196, 1), rgba(92, 149, 199, 1))'
    },
    subHeading: {
        fontWeight: '300',
        fontSize: 12,
        [theme.breakpoints.down('xs')]: {
            fontSize: 13,
        },
        textAlign: 'center'
    },
    statusIcon: {
        [theme.breakpoints.down('xs')]: {
            fontSize: 15
        }
    },
    listItem: {
        marginTop: 2,
        justifyContent: 'space-between',
        paddingTop: 15,
        paddingBottom: 15,
        [theme.breakpoints.down('xs')]: {
            paddingTop: 15,
            paddingBottom: 15
        }
    },
    bankCardAccountName: { fontSize: 17, color: 'white', fontFamily: "'Inconsolata', monospace", fontWeight: '500' },
    bankCardHeading: { fontSize: 25, color: 'white', fontFamily: "'Inconsolata', monospace", fontWeight: '700' },
    bankCardAccountMask: { fontSize: 20, color: 'white', letterSpacing: 5, fontFamily: "'Inconsolata', monospace", fontWeight: '500' },
    balanceContainer: { borderRadius: 5, border: '0.5px solid rgba(0,0,0,0.2)', padding: '0 5px 0px 5px', height: 145, marginTop: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
    balanceHeading: { color: '#fff', fontSize: 12, opacity: 0.5, fontFamily: "'Inconsolata', monospace", fontWeight: '500', letterSpacing: 1.2 },
    balance: { color: '#fff', letterSpacing: 3, fontSize: 30, marginTop: 4, fontFamily: "'Inconsolata', monospace", fontWeight: '500' },
    pageListItem: { border: '.5px solid #333', borderRadius: 5, marginTop: 3, fontSize: 12 }
}));


const MerchantDashboard = () => {
    const [loader, setLoader] = useState(false);
    const classes = useStyles();
    const mediaQuery = useMediaQuery('(max-width:800px)');
    const defaultStyles = useDefaultStyles();

    const [totalTransactions, setTotalTransactions] = useState(0);
    const [transactions, setTransations] = useState([]);
    const [transactionLabels, setTransactionLabels] = useState([]);
    const [transactionYears, setTransactionYears] = useState([]);
    const [showTransactions, setShowTransactions] = useState([]);
    const [selectTransactionYearForLine, setSelectTransactionYearForLine] = useState('');
    const [selectTransactionYearForBar, setSelectTransactionYearForBar] = useState('');
    const [transactionStatus, setTransactionStatus] = useState([]);
    const [transactionsPerMonth, setTransactionsPerMonth] = useState([]);
    const [allTransactionWithMonths, setAllTransactionWithMonths] = useState([]);
    const [latestTransactions, setLatestTransactions] = useState([]);
    const [latestTransactionLoading, setLatestTransactionsLoading] = useState(false);
    const [user, setUser] = useState({});
    const [defaultAccount, setDefaultAccount] = useState(null);
    const [date, setDate] = useState({
        date: new Date().toDateString(),
        time: new Date().toLocaleTimeString()
    });
    const [pageData, setPageData] = useState({});
    const [settingsLoading, setSettingsLoading] = useState(false);
    const pageRefs = useRef([]);
    pageRefs.current = [1, 2].map((element, i) => pageRefs.current[i] ?? createRef());
    let timer;
    useEffect(() => {
        Promise.all([getAllTransactions(), getBanks(), getUser()]).then(() => setLoader(false)).catch(() => setLoader(false));

        updateTime();
        return () => clearTimeout(timer);
    }, []);

    const updateTime = () => {
        timer = setInterval(() => setDate({
            date: new Date().toDateString(),
            time: new Date().toLocaleTimeString()
        }), 1000);
    }

    const getUser = async () => {
        try {
            const res = await getProfile();
            setUser(res);
        } catch (e) {
            console.log(e);
        }
    }

    const getBanks = async () => {
        setLoader(true);
        try {
            const res = await getMyBanks();
            setLoader(false);
            if (res.error) {
                setDefaultAccount(null);
                return;
            }
            if (res.data.success) {
                res.data.data.customer_accounts.map(account => {
                    if (account.is_default) {
                        setDefaultAccount(account);
                    }
                });
            }
            setLoader(false);
        } catch (e) {
            console.log(e);
        }
    }
    const getAllTransactions = async () => {
        try {
            setLoader(true);
            setLatestTransactionsLoading(true);
            const res = await getWalletTransactions();
            if (res.error) {
                openComp({ compName: "snackbar", payload: { message: res.error.message, severity: 'error' } });
                return;
            }

            if (res.data.success) {
                let transactionCountObject = {};
                let transactionPerMonthObject = {};
                let approve = 0;
                let pending = 0;

                // if(res.data)
                const latestTransactions = res.data.data.wallet_transactions.slice(0, 5);
                setLatestTransactions(latestTransactions);
                setLatestTransactionsLoading(false);

                res.data.data.wallet_transactions.reverse().map(transaction => {
                    const date = transaction.created_at.split('T')[0].split('-');
                    if (transaction.status === "SUCCESS") {
                        approve += 1;

                        if (transaction.transaction_type === "CREDIT") {

                            if (!transactionPerMonthObject[`${date[0]}-${date[1]}`]) {
                                transactionPerMonthObject[`${date[0]}-${date[1]}`] = {
                                    credit: (transaction.transaction_amount || 0)
                                }
                            } else {
                                // Transaction amount per month 
                                transactionPerMonthObject[`${date[0]}-${date[1]}`]['credit'] = (transactionPerMonthObject[`${date[0]}-${date[1]}`]['credit'] || 0) + transaction.transaction_amount;
                            }
                        }
                        else if (transaction.transaction_type === 'DEBIT') {
                            // Transaction amount per month 
                            if (!transactionPerMonthObject[`${date[0]}-${date[1]}`]) {
                                transactionPerMonthObject[`${date[0]}-${date[1]}`] = {
                                    debit: (transaction.transaction_amount || 0)
                                }
                            } else {
                                // Transaction amount per month 
                                transactionPerMonthObject[`${date[0]}-${date[1]}`]['debit'] = (transactionPerMonthObject[`${date[0]}-${date[1]}`]['debit'] || 0) + transaction.transaction_amount;
                            }

                        }
                    }
                    if (transaction.status === 'PENDING') {
                        pending += 1;
                    }
                    if (transaction.transaction_type === "CREDIT") {
                        // Transaction amount per month 

                        // Transactions per month
                        if (!transactionCountObject[`${date[0]}-${date[1]}`]) {
                            transactionCountObject[`${date[0]}-${date[1]}`] = {
                                credit: (transactionCountObject[`${date[0]}-${date[1]}`] || 0) + 1
                            }

                            return;
                        }
                        transactionCountObject[`${date[0]}-${date[1]}`]['credit'] = (transactionCountObject[`${date[0]}-${date[1]}`]['credit'] || 0) + 1;
                    }
                    else if (transaction.transaction_type === "DEBIT") {

                        // Transactions per month
                        if (!transactionCountObject[`${date[0]}-${date[1]}`]) {
                            transactionCountObject[`${date[0]}-${date[1]}`] = {
                                debit: (transactionCountObject[`${date[0]}-${date[1]}`] || 0) + 1
                            }
                            return;
                        }
                        transactionCountObject[`${date[0]}-${date[1]}`]['debit'] = (transactionCountObject[`${date[0]}-${date[1]}`]['debit'] || 0) + 1;
                    }
                });

                setTransactionStatus([approve, pending]);
                // Dummy Data

                // transactionCountObject['2021-05'] = { credit: 41, debit: 24 };
                // transactionCountObject['2022-06'] = { credit: 26, debit: 49 };
                // transactionCountObject['2021-07'] = { credit: 45, debit: 51 };
                // transactionCountObject['2021-08'] = { credit: 54, debit: 40 };
                // transactionCountObject['2021-09'] = { credit: 19, debit: 15 };
                // transactionCountObject['2021-10'] = { credit: 28, debit: 43 };
                // transactionCountObject['2021-11'] = { credit: 19, debit: 15 };
                // transactionCountObject['2021-12'] = { credit: 28, debit: 43 };

                // transactionCountObject['2022-08'] = { credit: 54, debit: 76 };
                // transactionCountObject['2022-09'] = { credit: 44, debit: 29 };
                // transactionCountObject['2022-10'] = { credit: 50, debit: 34 };




                // transactionPerMonthObject['2021-05'] = { credit: 28131.15, debit: 15544.99 };
                // transactionPerMonthObject['2021-06'] = { credit: 43021.20, debit: 30000 };
                // transactionPerMonthObject['2021-08'] = { credit: 54000, debit: 40000 };
                // transactionPerMonthObject['2021-09'] = { credit: 19000.15, debit: 15544.99 };
                // transactionPerMonthObject['2021-10'] = { credit: 28131.15, debit: 43000.99 };
                // transactionPerMonthObject['2021-11'] = { credit: 30000.15, debit: 21544.99 };
                // transactionPerMonthObject['2021-12'] = { credit: 43211.15, debit: 12544.99 };

                // transactionPerMonthObject['2022-10'] = { credit: 70000, debit: 20000 };
                // transactionPerMonthObject['2022-11'] = { credit: 44000, debit: 50000 };
                // transactionPerMonthObject['2022-12'] = { credit: 81200, debit: 34000 };

                const { transactions, years } = sortTransactionsWithMonth(Object.entries(transactionCountObject));
                setAllTransactionWithMonths(sortTransactionsWithMonth(Object.entries(transactionPerMonthObject)).transactions);

                const { showTransactions, labels } = processData(Object.entries(transactionCountObject), years[0]);




                let totalTransactions = 0;
                transactions.map(transaction => totalTransactions += ((transaction[1].credit || 0) + (transaction[1].debit || 0)));

                setTotalTransactions(totalTransactions);
                setTransations(transactions);
                setTransactionLabels(labels);
                setTransactionYears(years);
                setShowTransactions(showTransactions);
                setSelectTransactionYearForLine(years[0].value);
                setSelectTransactionYearForBar(years[0].value);
                setTransactionsPerMonth(processData(Object.entries(transactionPerMonthObject), years[0]).showTransactions);
            }
            // setLoader(false);
        } catch (e) {
            setLatestTransactionsLoading(false);
        }
    }

    const sortTransactionsWithMonth = (data) => {
        const years = [];
        const transactions = data.map((obj, index) => {
            if (!years.some(year => year.label === obj[0].split('-')[0])) {
                years.push({ value: index, label: obj[0].split('-')[0] });
            }
            return obj;
        });
        return { transactions, years };
    }

    const processData = (data, year) => {
        const showTransactions = [];
        const labels = [];
        const credit = [];
        const debit = [];
        data.filter(obj => {
            if (year.label === obj[0].split('-')[0]) {
                if ('credit' in obj[1]) {
                    credit.push(obj[1].credit.toFixed(2));

                }
                if ('debit' in obj[1]) {
                    debit.push(obj[1].debit.toFixed(2));
                }
                labels.push(months[obj[0].split('-')[1]]);
            }
        });
        showTransactions.push({
            name: 'Added to Noola Wallet',
            data: credit,
        }, {
            name: 'Transfered to Bank Account',
            data: debit,
        });

        return { showTransactions, labels };
    }
    const onTransactionYearChange = (value, type) => {


        if (type === 'line') {
            const year = transactionYears.filter(year => year.value === value)[0];
            setSelectTransactionYearForLine(value);
            const transactionByYear = transactions.filter(transaction => transaction[0].split('-')[0] === year.label);

            const { showTransactions, labels } = processData(transactionByYear, year);

            setShowTransactions(showTransactions);
            setTransactionLabels(labels);
        }
        else if (type === 'bar') {
            const year = transactionYears.filter(year => year.value === value)[0];
            setSelectTransactionYearForBar(value);
            const transactionByYear = allTransactionWithMonths.filter(transaction => transaction[0].split('-')[0] === year.label);

            const { showTransactions, labels } = processData(transactionByYear, year);

            setTransactionsPerMonth(showTransactions);
            setTransactionLabels(labels);
        }
    };


    const renderTransactionTable = useMemo(() => <List>
        <ListSubheader disableSticky style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0px 12px 20px 0px rgba(0,0,0,0.019)' }}>
            <Typography variant="body2">Latest Transactions</Typography>
            <Button
                component={Link}
                to={'/merchantTransactions?transaction_source=ALL&transaction_type=ALL'}
                variant="text"
                style={{ fontSize: 12 }}>View All</Button>
        </ListSubheader>

        {latestTransactions.map(transaction => <ListItem key={transaction.transaction_id} className={classes.listItem}>
            <Grid container spacing={2} style={{ display: 'flex', alignItems: 'left' }}>
                {
                    !mediaQuery && <Grid item xs={4}>
                        <div style={{ marginLeft: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <Typography variant="subtitle1" className={classes.heading}>{transaction.institution_name}</Typography>
                            <Typography variant="body2" className={classes.subHeading} style={{ fontWeight: '500' }}>{transaction.account_name}</Typography>
                        </div>
                    </Grid>
                }
                {!mediaQuery && <Grid item xs={2}><Typography variant="body2" className={classes.subHeading} style={{ marginLeft: 10, fontWeight: '500' }}>********{transaction.account_mask}</Typography></Grid>}
                <Grid item xs={8} sm={2} style={{ display: 'flex', alignItems: 'center' }}>
                    <Typography variant="body2" className={classes.subHeading} style={{ marginLeft: 10, fontWeight: '500', textAlign: 'left' }}>{transaction.transaction_type === 'DEBIT' ? 'Transferred to Bank Account' : 'Added to Noola Wallet'}</Typography>
                </Grid>

                <Grid item xs={2} sm={1}>
                    <Typography
                        variant="body2"
                        className={classes.subHeading}
                        style={{ fontWeight: '700', color: transaction.transaction_type === "CREDIT" ? colorPalette.success : colorPalette.danger }}>
                        {transaction.transaction_type === "CREDIT" ? '+' : '-'}{numberWithCommas(kFormatter(transaction.transaction_amount))}
                    </Typography>
                </Grid>
                {!mediaQuery && <Grid item xs={2}>
                    <Typography variant="body2" className={classes.subHeading} >{transaction.created_at.split('T')[0] + ' ' + transaction.created_at.split('T')[1].split('.')[0]}</Typography>
                </Grid>}
                <Grid item xs={2} sm={1} style={{ display: 'flex', alignItems: 'center', justifyContent: mediaQuery ? 'flex-end' : 'center' }}>
                    {transaction.status === 'SUCCESS' ? <Tooltip title="Approved">
                        <CheckCircleOutlineIcon className={classes.statusIcon} style={{ color: colorPalette.success }} />
                    </Tooltip> : <Tooltip title="Pending">
                        <UpdateIcon className={classes.statusIcon} style={{ color: colorPalette.pending }} />
                    </Tooltip>}
                </Grid>
            </Grid>
        </ListItem>)}
    </List>, [latestTransactions, classes]);

    const renderTimeAndDate = useMemo(() => <div style={{ color: '#fff', textAlign: 'left', marginTop: 1 }}>
        <div style={{ height: 'fit-content', textAlign: 'left' }}>
            <Typography variant="h4" className={classes.balanceHeading}>Wallet Balance</Typography>
            <Typography variant="h3" className={classes.balance}>${user.wallet_total_balance ? numberWithCommas(kFormatter(user.wallet_total_balance)) : '0.00'}</Typography>
        </div>
    </div>, [date]);

    const renderDoughnatChart = useMemo(() => <AreaGraph
        labels={['Approved', 'Pending']}
        data={transactionStatus}
        title="Transaction status"
    />, [transactionStatus]);

    const renderTransactionLineGraph = useMemo(() => <MultiLine
        labels={transactionLabels}
        colors={['#3772FF', '#FDCA44']}
        height={mediaQuery ? 220 : 210}
        title="Total Transactions"
        data={showTransactions} />, [showTransactions, loader]);

    const renderTransactionBarGraph = useMemo(() => <MultiBar
        height={mediaQuery ? 220 : 258}
        labels={transactionLabels}
        data={transactionsPerMonth}
        title="Transactions in Amount"
    />, [transactionsPerMonth, mediaQuery]);


    const changePage = (i, value) => {

        if (i === 0) {
            pageRefs.current[0].current.style.opacity = 0;
            pageRefs.current[0].current.style.transform = `translateX(-100%)`;
            pageRefs.current[1].current.style.transform = `translateX(-100%)`;
            pageRefs.current[1].current.style.opacity = 1;
            if (value) {
                setPageData(value);
            }
        } else if (i === 1) {
            pageRefs.current[0].current.style.opacity = 1;
            pageRefs.current[0].current.style.transform = `translateX(0)`;
            pageRefs.current[1].current.style.transform = `translateX(0)`;
            pageRefs.current[1].current.style.opacity = 0;
        }

    }

    const updateSettings = async (key, value) => {
        try {
            const res = await updateMerchantProfile({
                [key]: value
            });
            await getUser();
            changePage(1);
            setSettingsLoading(false);
            return res;
        } catch(e) {
            openComp({ compName: "snackbar", payload: { message: e.message, severity: 'error' } });
            setSettingsLoading(false);
        }
    }
    const onChangeTransactionSettings = async () => {
        if (pageData) {
           try {
            setSettingsLoading(true)
            if (pageData.item === 'Bank Transfer') {
                if (pageData.value > user.optimum_wallet_balance) {
                    const res = await updateSettings('bank_transfer_trigger_threshold', pageData.value);
                    if(res && res.success) {
                        openComp({ compName: "snackbar", payload: { message: "Bank Transfer Limit Updated.", severity: 'success' } });
                    }
                } else {
                    openComp({ compName: "snackbar", payload: { message: "To Transfer to Bank, Amount should be greater than Optimum Wallet Balance", severity: 'warning' } });
                }
            } else if (pageData.item === 'Wallet Recharge') {
                if (pageData.value < user.optimum_wallet_balance) {
                    const res = await updateSettings('recharge_trigger_threshold', pageData.value);
                    if(res && res.success) {
                        openComp({ compName: "snackbar", payload: { message: "Wallet Recharge Limit Updated.", severity: 'success' } });
                    }
                } else {
                    openComp({ compName: "snackbar", payload: { message: "To Recharge Wallet, Amount should be less than Optimum Wallet Balance.", severity: 'warning' } });
                }
            } else if (pageData.item === 'Optimum Wallet Balance') {
                const res = await updateSettings('optimum_wallet_balance', pageData.value);
                if(res && res.success) {
                    openComp({ compName: "snackbar", payload: { message: "Optimum Wallet Balance Updated.", severity: 'success' } });
                } 
            }
            setSettingsLoading(false)
           } catch(e) {
               console.log(e);
           }
        }
    }
    return (
        <PageTag>
            <BarTag title="Dashboard" drawer={true} profile={true} dMode={false} />
            {loader ? <CircularLoader opened={true} />
                :
                <Container style={{ marginTop: -30 }}>
                    <Grid container spacing={2}>

                        <Grid item xs={12} sm={4}>
                            <Grid item xs={12} sm={12}>
                                <Paper elevation={CARD_ELEVATION}
                                    className={classes.bankCard}>
                                    {defaultAccount != null ? <div >
                                        <Typography style={{width: '90%', wordBreak: 'break-word'}} variant="h4" className={classes.bankCardHeading}>{defaultAccount.institution_name}</Typography>
                                        <div style={{ width: '100%', textAlign: 'left', display: 'flex' }}>
                                            <div>
                                                <Typography variant="h6" className={classes.bankCardAccountName}>{defaultAccount.account_name}</Typography>
                                                {/* <img style={{width: 50}} src={CARD_CHIP}  /> */}
                                                <FcSimCardChip style={{ fontSize: 50, marginLeft: -8 }} />
                                                <Typography variant="h6" className={classes.bankCardAccountMask} style={{ marginTop: mediaQuery ? -10 : 10, width: '150%' }}>**** **** {defaultAccount.account_mask}</Typography>
                                            </div>
                                            <div style={{ height: 'fit-content', width: 'fit-content', textAlign: 'right', marginTop: !mediaQuery ? 25 : 10 }}>
                                                <Typography variant="h4" className={classes.balanceHeading}>Wallet Balance</Typography>
                                                <Typography variant="h3" className={classes.balance}>${user.wallet_total_balance ? numberWithCommas(kFormatter(user.wallet_total_balance)) : '0.00'}</Typography>
                                            </div>
                                        </div>
                                    </div>
                                        :
                                        <div>
                                            <Typography variant="h3" style={{ fontSize: 17, color: 'white', fontFamily: "'Inconsolata', monospace", fontWeight: '500' }}>Welcome To, </Typography>
                                            <Typography variant="h4" style={{ fontSize: 42, lineHeight: 1.5, color: 'white', opacity: 0.6, fontFamily: "'Krona One', sans-serif", letterSpacing: 2, marginBottom: 10 }}>NOOLA</Typography>
                                            {renderTimeAndDate}
                                        </div>
                                    }
                                </Paper>
                            </Grid>

                            <Grid item xs={12} sm={12}>
                                <Paper elevation={CARD_ELEVATION} className={classes.balanceContainer} style={{ overflow: 'hidden' }}>

                                    {/* <div style={{ textAlign: 'right' }}>
                                        <Typography variant="h4" className={classes.balanceHeading}>Wallet Balance</Typography>
                                        <Typography variant="h3" className={classes.balance}>${user.wallet_total_balance ? numberWithCommas(kFormatter(user.wallet_total_balance)) : '0.00'}</Typography>
                                    </div>
                                    <Button
                                        component={Link}
                                        to="/accounts"
                                        disableElevation={true}
                                        style={{ background: colorPalette.primary, fontSize: 12 }}
                                        variant="contained"
                                        className={defaultStyles.button}
                                        startIcon={<Icon style={{ fontSize: 18 }}>add</Icon>}
                                    >
                                        Add Money
                                    </Button> */}


                                    {[
                                        <div>
                                            <List>
                                                <ListSubheader style={{ boxShadow: '0px 12px 20px 0px rgba(0,0,0,0.019)' }}><Typography variant="body2" style={{ fontSize: 11 }}>Transaction Settings</Typography></ListSubheader>
                                                <div>
                                                    <ListItem style={{ cursor: 'pointer', justifyContent: 'space-between', color: '#333' }} onClick={() => changePage(0, { item: 'Bank Transfer', value: user.bank_transfer_trigger_threshold })}>Bank Transfer Limit<span style={{ display: 'flex', alignItems: 'center' }}>${user.bank_transfer_trigger_threshold ? numberWithCommas(kFormatter(user.bank_transfer_trigger_threshold.toFixed(2))) : '$0.00'}<ChevronRightIcon /></span> </ListItem>
                                                    <ListItem style={{ cursor: 'pointer', justifyContent: 'space-between', color: '#333' }} onClick={() => changePage(0, { item: 'Wallet Recharge', value: user.recharge_trigger_threshold })}>Wallet Recharge Limit<span style={{ display: 'flex', alignItems: 'center' }}>${user.recharge_trigger_threshold ? numberWithCommas(kFormatter(user.recharge_trigger_threshold.toFixed(2))) : '$0.00'}<ChevronRightIcon /></span></ListItem>
                                                    <ListItem style={{ cursor: 'pointer', justifyContent: 'space-between', color: '#333' }} onClick={() => changePage(0, { item: 'Optimum Wallet Balance', value: user.optimum_wallet_balance })}>Optimum Wallet Balance<span style={{ display: 'flex', alignItems: 'center' }}>${user.optimum_wallet_balance ? numberWithCommas(kFormatter(user.optimum_wallet_balance.toFixed(2))) : '$0.00'}<ChevronRightIcon /></span></ListItem>
                                                </div>
                                            </List>
                                        </div>,
                                        <div>
                                            <div>
                                                <List>
                                                    <ListSubheader style={{ boxShadow: '0px 12px 20px 0px rgba(0,0,0,0.019)' }}>
                                                        <div style={{ cursor: 'pointer', width: 'fit-content', display: 'flex', alignItems: 'center', marginLeft: -16 }} onClick={() => changePage(1)}>
                                                            <ChevronLeftIcon />
                                                            <Typography variant="body2" style={{ fontSize: 13 }}>{pageData.item}</Typography>
                                                        </div>
                                                    </ListSubheader>
                                                    <ListItem style={{ alignItems: 'center', justifyContent: 'center' }}>
                                                        <div style={{ width: '85%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', alignSelf: 'center', marginLeft: -20 }}>
                                                            <Input
                                                                type="tel"
                                                                value={pageData.value != '' ? pageData.value : ''}
                                                                onChange={e => setPageData({ ...pageData, value: e.target.value })}
                                                                error={pageData.value < 0}
                                                                helperText={pageData.value < 0 ? 'Please enter valid amount' : ''}
                                                                id="formatted-numberformat-input"
                                                                InputProps={{
                                                                    inputComponent: NumberFormatCustom,
                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                }}
                                                                style={{ display: 'block', marginTop: 5 }}
                                                            />
                                                            <br></br>
                                                            <Button
                                                                disabled={settingsLoading}
                                                                onClick={onChangeTransactionSettings}
                                                                disableElevation={true}
                                                                style={{ background: colorPalette.primary, fontSize: 12, color: '#fff', marginTop: -15, width: '100%' }}
                                                                variant="contained">
                                                                {settingsLoading ? <CircularLoader size={20} style={{color: '#fff'}} opened={true} /> : 'Update'}
                                                        </Button>
                                                        </div>
                                                    </ListItem>
                                                </List>
                                            </div>
                                        </div>
                                    ].map((el, i) => <div key={i} ref={pageRefs.current[i]} style={{ minWidth: '103%', height: '100%', transition: 'all 0.7s cubic-bezier(0.39, 0.575, 0.565, 1)', willChange: 'transform' }}>
                                        {el}
                                    </div>)}
                                </Paper>

                            </Grid>
                        </Grid>

                        <Grid item xs={12} sm={8}>
                            <Paper elevation={CARD_ELEVATION} className={classes.paper}>
                                <div className={classes.buttonContainer}>
                                    <div></div>
                                    <div style={{ textAlign: 'right' }}>
                                        <Select
                                            style={{ height: 30, width: 100, marginLeft: 20, marginTop: -10 }}
                                            name="transactionYearBar"
                                            options={transactionYears}
                                            onChange={({ target: { value } }) => onTransactionYearChange(value, 'bar')}
                                            value={selectTransactionYearForBar}
                                        />
                                    </div>
                                </div>
                                <div>
                                    {renderTransactionBarGraph}
                                </div>
                            </Paper>
                        </Grid>
                    

                        <Grid item xs={12} sm={6}>
                            <Paper elevation={CARD_ELEVATION} className={classes.paper}>
                                <div className={classes.buttonContainer}>
                                    <Tooltip title="All Transactions">
                                        <IconButton
                                            component={Link}
                                            to={'/merchantTransactions?transaction_source=ALL&transaction_type=ALL'}
                                            size="small"
                                            style={{ background: colorPalette.primary, boxShadow: BOX_SHADOW, color: '#fff', padding: 10, fontSize: 9, marginTop: -30 }}
                                            variant="contained">
                                            <AccountBalanceWalletIcon style={{ fontSize: 20 }} />
                                        </IconButton>
                                    </Tooltip>
                                    <div style={{ textAlign: 'right' }}>
                                        <Typography variant="caption">Transactions</Typography>
                                        <Typography variant="subtitle2">{totalTransactions}</Typography>
                                        <Select
                                            style={{ height: 30, width: 100, marginLeft: 20, marginTop: -10 }}
                                            name="transactionYear"
                                            options={transactionYears}
                                            onChange={({ target: { value } }) => onTransactionYearChange(value, 'line')}
                                            value={selectTransactionYearForLine}
                                        />
                                    </div>
                                </div>
                                <div>
                                    {renderTransactionLineGraph}
                                </div>
                            </Paper>
                        </Grid>



                        <Grid item xs={12} sm={6}>
                            <Paper elevation={CARD_ELEVATION} style={{ maxHeight: 200 }} className={classes.paper}>
                                <div className={classes.buttonContainer}>
                                    <div></div>
                                    <div style={{ textAlign: 'right' }}>
                                        <Typography variant="caption">Transactions</Typography>
                                        <Typography variant="subtitle2">{totalTransactions}</Typography>
                                        <div></div>
                                    </div>

                                </div>
                                <div style={{ height: 260 }}>
                                    {renderDoughnatChart}
                                </div>
                            </Paper>
                        </Grid>
                        <Grid item xs={12}>
                            <Paper style={{ padding: 0, marginTop: -2 }} elevation={CARD_ELEVATION} className={classes.paper}>
                                {latestTransactionLoading ? <CircularLoader opened={true} /> : latestTransactions.length ? renderTransactionTable :
                                    <div style={{ textAlign: 'center', padding: 40 }}>
                                        <AccountBalanceWalletIcon style={{ fontSize: 200, color: '#f0f0f0' }} />
                                        <Typography variant="h6" style={{ color: '#ccc' }}>Your latest Transactions will be shown here!</Typography>
                                    </div>}
                            </Paper>
                        </Grid>

                    </Grid>
                </Container>
            }
        </PageTag>
    )
};

export default connect(store => ({
}))(MerchantDashboard);