import { Button, makeStyles } from '@material-ui/core';
import React from 'react';
import { colorPalette } from '../../libs/styleProvider';

const useStyles = makeStyles(theme => ({
    button: (props) => {
        return {
            // border: `2px solid ${colorPalette.primary}`,
            // borderRadius: 25,
            background: props.btnType === 'success' ? colorPalette.success : props.btnType === 'danger' ? colorPalette.danger : colorPalette.primary,
            '&:hover': {
                background: props.btnType === 'success' ? colorPalette.successDark : props.btnType === 'danger' ? colorPalette.dangerDark : colorPalette.primaryDark
            },
            '&:disabled': {
                background: 'transparent',
                color: '#000',
                border: 0
            },
            [theme.breakpoints.down('md')]: {
                marginTop: 3
            },
            color: '#fff',
            minHeight: 15,
            minWidth: 50,
            textAlign: 'center',
            fontSize: 10,
    
        }
    }
}));
function TableButton({children, btnType, variant, ...props}) {
    const classes = useStyles({...props, btnType});
    return (
        <Button {...props} disableElevation variant={"contained"} className={classes.button}>{children}</Button>
    );
}

export default TableButton;