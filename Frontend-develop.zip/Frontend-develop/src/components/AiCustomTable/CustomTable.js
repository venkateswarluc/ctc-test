import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import { lighten, makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import AiInput from '../AiForm/AiInput';
import { useToolbarStyles, useTableStyles } from './styles';
import { stableSort } from '../../libs/sorting';
import { Grid } from '@material-ui/core';
import { Link } from 'react-router-dom';

import { colorPalette } from '../../libs/styleProvider';

export default function CustomTable(props) {
  const classes = useTableStyles();
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState(0);
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [rows, setRows] = useState([]);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [search, setSearch] = useState('');

  const { data, tableHead, link, extraRows, style } = props;

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };
  const createSortHandler = (property) => (event) => {

    handleRequestSort(event, property);
  };
  useEffect(() => {
    if (data) {
      let filtered = data;
      
      if (search) {
        
        filtered = filtered.filter(entry => Object.values(entry).some(val => typeof val === "string" ? val.toLowerCase().includes(search.toLowerCase()) : typeof val === "number" && val.toString().includes(search)));
      }
      
      setRows(filtered);
      setPage(0);
    }

  }, [data, search]);




  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }

    setSelected(newSelected);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  return (
    <div className={classes.root}>

      <Paper variant="outlined" className={classes.paper} style={style}>
        <Grid container>
          <Grid item xs={12} sm={3}>
            <AiInput
              placeholder="Search..."
              // name="password" 
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value) }}
            />
          </Grid>
        </Grid>
        <TableContainer>
          <Table
            className={classes.table}
            aria-labelledby="tableTitle"
            aria-label="enhanced table"
          >
            <TableHead>
              <TableRow>
                {tableHead.map((headCell) => (
                  // ID needs to be key in data
                  <TableCell
                    key={headCell.id}
                    align={'left'}
                    sortDirection={orderBy === headCell.id ? order : false}>
                    <TableSortLabel
                      active={orderBy === headCell.id}
                      direction={orderBy === headCell.id ? order : 'asc'}
                      onClick={createSortHandler(headCell.id)}>
                      {headCell.label}
                    </TableSortLabel>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {stableSort(rows, order, orderBy)
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => {
                  const labelId = `enhanced-table-checkbox-${index}`;
                  return (
                    <TableRow
                      hover
                      onClick={(event) => handleClick(event, row.company_name)}
                      tabIndex={-1}
                      key={row.id}
                    >
                      {Object.entries(row).slice(0, Object.entries(row).length - 1).map((item, key) => {
                        if (typeof (item[1]) === 'boolean') {
                          return <TableCell key={key} style={{ width: 60 }} className={classes.tableCell} align="left">
                            <Typography variant="subtitle2" style={{ fontSize: 12 }}>
                              {item[1].toString().toUpperCase()}
                            </Typography>
                          </TableCell>
                        }
                        else if (item[0] === "transaction_amount" && "transaction_type" in row) {
                          return <TableCell key={key} style={{ color: row.transaction_type === "Added to Noola Wallet" ? colorPalette.success : colorPalette.danger }} className={classes.tableCell} align="left">
                            <Typography variant="subtitle2" style={{ fontSize: 12, fontWeight: '700' }}>{row.transaction_type === "Added to Noola Wallet" ? "+" : "-"}{item[1]}</Typography>
                          </TableCell>
                        }
                        else if (typeof item[1] === 'string') {
                          return <TableCell key={key} className={classes.tableCell} align="left">
                            <Typography variant="subtitle2" style={{ fontSize: 13 }}> {item[1]}</Typography>
                          </TableCell>
                        } else {
                          return <TableCell key={key} className={classes.tableCell} align="left" style={{minWidth: 20}}>
                             {item[1]}
                          </TableCell>
                        }
                       
                      })}
                      {extraRows && extraRows(row).map((children, key) => {
                        return <TableCell key={key} align="left">
                          {children}
                        </TableCell>
                      }
                      )}
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
        />
      </Paper>
    </div>
  );
}
