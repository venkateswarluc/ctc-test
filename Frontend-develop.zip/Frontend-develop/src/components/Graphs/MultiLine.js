import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'react-apexcharts';


function MultiLine({ data, labels, height, title, colors }) {

    const options = {
        responsive: true,
        maintainAspectRatio: true,
        animations: {
            y: {
                duration: 1000,
            },
        },
        plugins: {
            tooltip: {
                enabled: true
            },
            filler: {
                propagate: false,
            },
            title: {
                display: true,
                text: title,
                weight: '300'
            },
            legend: {
                display: true,
                position: 'bottom',
                // onClick: () => {},
                labels: {
                    boxWidth: 20,
                    boxHeight: 5,
                    font: {
                        size: 10
                    }
                }
            }
        },

        scaleLineColor: 'rgba(0,0,0,0)',
        showScale: false,
        elements: {
            line: { tension: 0.4 },
            point: {
                borderWidth: 3,
                hoverBorderWidth: 6
            }
        },
        scales: {
            x: {
                display: true,
                grid: {
                    display: false
                }
            },
            y: {
                display: false,
                grid: {
                    display: false,
                }
            }
        }
    };

    // const chartData = useMemo(() => ({
    //     labels,
    //     datasets: data,
    // }), [data]);

    const chartOptions = {
        chart: {
            id: 'multiLine',
            dropShadow: {
                enabled: true,
                color: '#000',
                top: 18,
                left: 7,
                blur: 10,
                opacity: 0.2
            },
            toolbar: {
                show: false
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800,
                animateGradually: {
                    enabled: true,
                    delay: 150
                },
                dynamicAnimation: {
                    enabled: true,
                    speed: 350
                }
            }
        },
        markers: {
            size: 4,
            colors,
            strokeColors: "rgba(255, 255, 255, 1)",
            strokeWidth: 2,
            hover: {
              size: 7,
            }
          },
        dataLabels: {
            enabled: true,
            style:{
                fontSize: 10
            }
            
        },
        colors,
        xaxis: {
            categories: labels
        },
        stroke: {
            curve: 'smooth'
        },
        
    };
    return (
        <Chart
            options={chartOptions}
            series={data}
            type="line"
            width="100%"
            height={height}
        />
    );
}

export default MultiLine;