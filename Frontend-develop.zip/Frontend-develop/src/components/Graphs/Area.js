import React, { memo } from 'react';
import { Doughnut, Pie } from 'react-chartjs-2';
import { colorPalette } from '../../libs/styleProvider';



function DoughnutGraph({data, labels, title, type = 'Doughnut'}) {

    const transactionData = {
        labels,
        datasets: [
            {
                label: 'Transactions',
                data,
                backgroundColor: [
                    colorPalette.success,
                    colorPalette.pending
                ],
                borderColor: [
                    colorPalette.success,
                    colorPalette.pending
                ],
                borderWidth: 1,
            },
        ],
    };
    if(type === 'Pie') {
        return (
            <Pie
            options={{
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: title,
                        position: 'bottom'
                    }
                }
            }}
            data={transactionData} />
        );
    }
    return (
        <Doughnut
        options={{
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: title,
                    position: 'bottom'
                }
            }
        }}
        data={transactionData} />
    );
}

export default memo(DoughnutGraph);