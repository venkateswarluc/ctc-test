import React, { useMemo } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import Chart from 'react-apexcharts';
import { kFormatter } from '../../libs/helper';



function MultiBar({ data, labels, height, title }) {
    const chartOptions = {
        chart: {
            id: 'multiBar',
            dropShadow: {
                enabled: true,
                color: '#000',
                top: 18,
                left: 7,
                blur: 10,
                opacity: 0.2
            },
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        stroke: {
            show: true,
            width: 5,
            colors: ['transparent']
          },
        plotOptions: {
            bar: {
                borderRadius: 5,
                rangeBarOverlap: false,
                  columnWidth: '55%',
                dataLabels: {
                    position: 'top',
                },
            }
        },
        dataLabels: {
            enabled: false,
            formatter: function (num) {
                return Math.abs(num) > 9999 ? Math.sign(num) * ((Math.abs(num) / 1000).toFixed(1)) + 'k' : Math.sign(num) * Math.abs(num);
            },
            style: {
                fontSize: '12px',
                colors: ["#304758"]
            }
        },
        xaxis: {
            categories: labels,

        },
        theme: {
            palette: 'palette8',
            
        }
    };
    return (
        <Chart
            options={chartOptions}
            series={data}
            type="bar"
            width="100%"
            height={height}
        />
    );
}

export default MultiBar;