import React, { memo, useEffect, useRef, useState } from 'react';
import { Line } from 'react-chartjs-2';
import { getGradient } from '../../libs/helper';
import { colorPalette } from '../../libs/styleProvider';
import Chart from 'react-apexcharts';

const options = {
    responsive: true,
    maintainAspectRatio: true,
    animations: {
        y: {
            duration: 1000,
            // easing: 'ease',
        },
    },
    plugins: {
        tooltip: {
            enabled: true
        },
        filler: {
            propagate: true,
        },
    },
    legend: {
        display: false
    },
    scaleLineColor: 'rgba(0,0,0,0)',
    showScale: false,
    elements: {
        point: {
            borderWidth: 2,
            hoverBorderWidth: 6
        },
        line: { tension: 0.4 }
    },
    scales: {
        x: {
            display: true,
            grid: {
                display: false
            }
        },
        y: {
            display: true,
            grid: {
                display: false
            }
        }
    }
};

const FILL = 'origin';

function LineGraph({ height, data, labels, title, colors }) {
    const [chartValues, setChartValues] = useState({});
    const ref = useRef();
    // const chartData = (canvas) => {
    //     const ctx = canvas.getContext('2d')
    //     return {
    //         labels,
    //         datasets: [{
    //             label: title,
    //             // backgroundColor: 'rgb(255, 99, 132)',
    //             backgroundColor: (context) => {
    //                 const chart = context.chart;
    //                 const { ctx, chartArea } = chart;

    //                 if (!chartArea) {
    //                     // This case happens on initial chart load
    //                     return null;
    //                 }
    //                 return getGradient(ctx, chartArea, colors.bottom, colors.middle, colors.top);
    //             },
    //             borderColor: colorPalette.primary,
    //             data: data,
    //             fill: FILL
    //         }]
    //     }
    // }

    const chartOptions =  {
       
        chart: {
            id: 'multiBar',
           
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            },
            dropShadow: {
                enabled: true,
                color: '#000',
                top: 18,
                left: 7,
                blur: 20,
                opacity: 0.2
            },
        },
        fill: {
            type: 'gradient',
            gradient: {
              shadeIntensity: 1,
              inverseColors: false,
              opacityFrom: 0.5,
              opacityTo: 0,
              stops: [0, 90, 100]
            },
          },
          markers: {
            size: 5,
            colors,
            strokeColors: "rgba(255, 255, 255, 1)",
            strokeWidth: 2,
            hover: {
              size: 7,
            }
          },
        
        dataLabels: {
            enabled: false,
            formatter: function (num) {
                return Math.abs(num) > 9999 ? Math.sign(num) * ((Math.abs(num) / 1000).toFixed(1)) + 'k' : Math.sign(num) * Math.abs(num);
            },
            style: {
                fontSize: '12px',
                colors: ["#304758"]
            }
        },
        xaxis: {
            categories: labels,

        },
        stroke: {
            curve: 'straight',
            lineCap: 'square'
        },
      }
    return (
        <Chart
            options={chartOptions}
            series={data}
            type="area"
            width="100%"
            height={height}
        />
    );
}

export default memo(LineGraph);