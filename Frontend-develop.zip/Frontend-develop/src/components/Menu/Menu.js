import { ClickAwayListener, Grow, MenuItem, MenuList, Paper, Popper, Menu } from '@material-ui/core';
import React, { useEffect, useRef, useState } from 'react';

function MenuContainer({ opened, children, anchorRef, handleClose }) {
    const [open, setOpen] = useState(opened);

    function handleListKeyDown(event) {
        if (event.key === 'Tab') {
            event.preventDefault();
            setOpen(false);
        }
    };
    return (
        <Popper open={opened} anchorEl={anchorRef.current} role={undefined} transition disablePortal>
            {({ TransitionProps, placement }) => (
                <Grow
                {...TransitionProps}
                style={{ transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom' }}
            >
                <Paper>
                    <Menu
                        getContentAnchorEl={null}
                        anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'center',
                        }}
                        transformOrigin={{
                            vertical: 'top',
                            horizontal: 'center',
                        }}
                        keepMounted
                        onClose={handleClose}
                        open={opened} anchorEl={anchorRef.current} id="menu-list-grow" onKeyDown={handleListKeyDown}>
                       <MenuList> {children}</MenuList>
                    </Menu>
                </Paper>
                </Grow>
            )}
        </Popper>
    );
}

export default MenuContainer;