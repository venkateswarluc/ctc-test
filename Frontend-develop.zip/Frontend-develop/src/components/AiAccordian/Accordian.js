import React from 'react';
import { Accordion, AccordionDetails, AccordionSummary, Button, Grid, makeStyles, Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';


const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    summary: {
        display: 'flex',
        justifyContent: 'right'
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        textAlignLast: 'right'
    },
    secondaryHeading: {
        fontSize: theme.typography.pxToRem(15),
        color: theme.palette.text.secondary,
    },
}));

function Accordian({ title, children, ...props }) {
    const classes = useStyles();
    const [expanded, setExpanded] = React.useState(false);
    const handleChange = (panel) => (event, isExpanded) => {
        setExpanded(isExpanded ? panel : false);
    };
    return (
        <Accordion
            {...props}
            elevation={0}
            expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
            <AccordionSummary
                classes={{root: classes.summary}}
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1bh-content"
                id="panel1bh-header"
            >
               <Typography
                            className={classes.heading}>
                            {title}
                </Typography>
            </AccordionSummary>
            <AccordionDetails>
                {children}
            </AccordionDetails>
        </Accordion>
    );
}

export default Accordian;