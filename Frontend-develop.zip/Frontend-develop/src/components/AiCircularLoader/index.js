import React, { Fragment } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';

const useStyles = makeStyles((theme) => ({
    root: {
       display: 'flex',
       justifyContent: 'center',
       alignItems: 'center',
       height: '100%'
    },
}));


const AiLoader = ({ opened = false, ...props }) => {
    const classes = useStyles();


    return (
        <Fragment>
            {
                opened
                    ?
                    <div className={classes.root}>
                        <CircularProgress  {...props} />
                    </div>
                    :
                    null
            }
        </Fragment>
    );
};



export default AiLoader;
