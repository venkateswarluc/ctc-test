import React, { Fragment } from "react";

//MAT-UI
import Snackbar from '@material-ui/core/Snackbar';
import IconButton from '@material-ui/core/IconButton';
import Icon from '@material-ui/core/Icon';
import MuiAlert from '@material-ui/lab/Alert';
import { makeStyles } from '@material-ui/core/styles';
import Slide from '@material-ui/core/Slide';
function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
}
function SlideTransition(props) {
    return <Slide {...props} direction="left" />;
}
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        '& > * + *': {
            marginTop: theme.spacing(2),
        },
    },
}));
const AiSnackbar = (props) => {
    const {
        opened = false,
        message = '',
        color = 'inherit',
        onClose,
        className,
        severity = 'success',
        ...others
    } = props;
    const classes = useStyles();


    // return (
    //     <Snackbar
    //         anchorOrigin={{
    //             vertical: 'top',
    //             horizontal: 'right',
    //         }}
    //         open={opened}
    //         autoHideDuration={6000}
    //         onClose={onClose}
    //         message={message}
    //         action={
    //             <IconButton size="small" aria-label="close" color="secondary" onClick={onClose}>
    //                 <Icon fontSize="small">close</Icon>
    //             </IconButton>
    //         }
    //     />
    // );
    return (
        <Snackbar
            anchorOrigin={{
                vertical: 'top',
                horizontal: 'right',
            }}
            style={{marginTop: 40}}
            open={opened}
            autoHideDuration={6000}
            onClose={onClose}
            >
            <Alert onClose={onClose} severity={severity}>
                {message}
            </Alert>
        </Snackbar>
    )
}

export default AiSnackbar;