import React from "react";


//MAT-UI 
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import Icon from '@material-ui/core/Icon';
import Zoom from '@material-ui/core/Zoom';
import Typography from '@material-ui/core/Typography';
import { DialogActions, DialogContentText } from "@material-ui/core";
import CircularLoader from '../AiCircularLoader';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Zoom ref={ref} {...props} />;
});


const AiModal = (props) => {
    const {
        opened = false,
        fullScreen = true,
        onDone,
        title,
        warning,
        loading,
        className,
        children,
        ...others
    } = props;

    const handleClose = (isOk) => {
        onDone(isOk);
    }
    return (
        <Dialog
        open={opened}
        onClose={() => handleClose(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description">
        <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
        <DialogContent>
            <div id="alert-dialog-description">
                {warning}
            </div>
        </DialogContent>
        <DialogActions>
            <Button onClick={() => handleClose(false)} color="primary">
                Cancel
            </Button>
            <Button onClick={() => handleClose(true)} disabled={loading} color="primary" style={{ maxHeight: 40 }}>
           {children}
            </Button>
        </DialogActions>
        </Dialog>
    )

};


export default AiModal;
