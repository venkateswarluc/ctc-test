import React from 'react';


import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import FormLabel from '@material-ui/core/FormLabel';

const AiCheckBox = (props) => {
    const {
        inline = true,
        variant = "outlined",
        margin = "normal",
        fullWidth = true,
        options = [],
        selectedValues = [],
        ...others
    } = props;

    let label = props.label || props.name;


    return (
        <FormControl fullWidth={fullWidth} variant={variant} margin={margin}>
            <FormLabel className="w3-caps" component="legend">{label}</FormLabel>

            <FormGroup row={inline ? true : false}>
                {options.map((opt, i) => {
                    let ariaLabelledby = `checkbox_id_${props.name}_${i}_${opt.value}`;
                    return (
                        <FormControlLabel
                            key={ariaLabelledby}
                            control={
                                <Checkbox
                                    color="primary"
                                    value={opt.value}
                                    checked={
                                        selectedValues && (selectedValues.includes(opt.value)
                                            || selectedValues.includes(String(opt.value)))
                                    }
                                    id={ariaLabelledby}
                                />
                            }
                            label={opt.label}
                            {...others}
                        />
                    );
                })}
            </FormGroup>
        </FormControl>
    );
};

export default AiCheckBox;
