import React from "react";

import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

const AiSelect = (props) => {
    const {
        variant = "outlined",
        margin = "normal",
        fullWidth = true,
        options = [],
        ...others
    } = props;

    let label = props.label || props.name;
    let ariaLabelledby = `select_id_${props.name}`;

    return (
        <FormControl fullWidth={fullWidth} variant={variant} size="small" margin={margin}>
            {/* <InputLabel htmlFor={ariaLabelledby} className="w3-caps">{label}</InputLabel> */}

            <Select 
                displayEmpty
          
                inputProps={{ 'aria-label': '' }} id={ariaLabelledby} className="w3-caps" style={{background: '#fff'}} {...others} >
                {options.map((opt, i) => (
                    <MenuItem key={`select_${props.name}_${i}_${opt.value}`} value={opt.value} className="w3-caps">{opt.label}</MenuItem>
                ))}
                
            </Select>
        </FormControl>
    );
};


export default AiSelect;
