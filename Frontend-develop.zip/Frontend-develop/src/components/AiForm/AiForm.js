import React, { useRef } from "react";

const AiForm = (props) => {
  let formRef = useRef(null);

  const {
    onDone = () => { },
    children,
    className,
    ...others
  } = props;

  const handleSubmit = e => {
    e.preventDefault();
    const form = formRef.current;
    if (validateForm(form)) {
      onDone(form);
    }
  };

  return (
    <form ref={formRef} className={className} onSubmit={handleSubmit} autoComplete="off" noValidate {...others} >
      {children}
    </form>
  );
};



const validateForm = (form) => {
  let firstInvalid = false;

  for (let el, i = 0;
    (el = form.elements[i]), i < form.elements.length; i++) {
    if (el.checkValidity()) {
      el.removeAttribute("aria-invalid");
    } else {
      if (!firstInvalid) {
        // announce error message
        if (el.nextElementSibling) {
          //this.fire('announce', el.nextElementSibling.getAttribute('error-message'));
        }
        if (el.scrollIntoViewIfNeeded) {
          // safari, chrome
          el.scrollIntoViewIfNeeded();
        } else {
          // firefox, edge, ie
          el.scrollIntoView(false);
        }
        el.focus();
        firstInvalid = true;
      }
      el.setAttribute("aria-invalid", "true");
    }
  }
  return !firstInvalid;
}


export default AiForm; 
