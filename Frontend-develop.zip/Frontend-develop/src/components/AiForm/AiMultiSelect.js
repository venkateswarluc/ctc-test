import React from "react";

import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Input from '@material-ui/core/Input';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';



const AiMultiSelect = (props) => {
    const {
        margin = "normal",
        fullWidth = true,
        options = [],
        selectedValues = [],
        ...others
    } = props;

    let label = props.label || props.name;
    let ariaLabelledby = `mselect_id_${props.name}`;


    return (
        <FormControl fullWidth={fullWidth} margin={margin}>

            <InputLabel htmlFor={ariaLabelledby} className="w3-caps">{label}</InputLabel>

            <Select label={label} id={ariaLabelledby} multiple
                input={<Input />}
                renderValue={(selected) => selected.map((value) => (
                    <Chip size="small" key={value} label={options.find(opt => String(opt.value) == String(value)).label || ''} style={{ marginRight: 1 }} />
                ))}
                {...others}
            >
                {options.map((opt, i) => (
                    <MenuItem key={`mselect_${props.name}_${i}_${opt.value}`} value={opt.value}>
                        <Checkbox
                            color="primary"
                            checked={selectedValues && (selectedValues.includes(opt.value) || selectedValues.includes(String(opt.value)))}
                        />
                        <ListItemText primary={opt.label} />
                    </MenuItem>
                ))}
            </Select>
        </FormControl>
    );
};


export default AiMultiSelect;
