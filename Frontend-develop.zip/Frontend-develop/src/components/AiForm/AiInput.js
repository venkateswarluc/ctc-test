import React, { Fragment } from "react";


import TextField from '@material-ui/core/TextField';
import { Input, InputBase, makeStyles } from "@material-ui/core";


const useStyles = makeStyles({
   input: { textTransform: `capitalize`, borderColor: "black", background: '#fff', boxShadow: '0px 0px 2px #888888', outlineStyle: 'none'}
})


const AiInput = (props) => {
  const {
    showLabel = true,
    variant = "outlined",
    margin = "normal",
    fullWidth = true,
    ...others
  } = props;
  const classes = useStyles();
  let label = props.label || props.name;
  let iType = props.type || "text";
  let ariaLabelledby = `${iType}_id_${props.name}`;


  let attrs = { id: ariaLabelledby };
  if (showLabel) {
    attrs.label = label;
  }
  if (iType != 'textarea') {
    attrs.type = iType;
  }
  if (iType == 'textarea') {
    attrs.rows = 4;
  }


  return (
    <TextField
      fullWidth={fullWidth}
      variant={variant}
      margin={margin}
      multiline={iType === 'textarea'}
      {...attrs}
      {...others}
      className={classes.input}
      size="small"
      // style={{ textTransform: `capitalize`, borderColor: "black", background: '#fff', height: 15 }}
    />
  );



  // return (<InputBase
  //   {...attrs}
  //   {...others}
  //   style={{ marginTop: 5, borderColor: '#000', borderRadius: 5, border: '.01px solid #ccc', background: '#fff', width: '100%', padding: 5 }}
  //   inputProps={{ 'aria-label': 'naked' }}
  // />)
};

export default AiInput;
