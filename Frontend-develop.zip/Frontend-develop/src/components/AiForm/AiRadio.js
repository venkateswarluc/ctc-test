import React from "react";

import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';

const AiRadio = (props) => {
    const {
        inline = true,
        margin = "normal",
        fullWidth = true,
        options = [],
        selectedValue,
        ...others
    } = props;

    let label = props.label || props.name;

    return (
        <FormControl fullWidth={fullWidth} margin={margin}>
            <FormLabel className="w3-caps" component="legend">{label}</FormLabel>

            <RadioGroup row={inline ? true : false} >
                {options.map((opt, i) => {
                    let ariaLabelledby = `radio_id_${props.name}_${i}_${opt.value}`;
                    return (
                        <FormControlLabel
                            key={ariaLabelledby}
                            control={
                                <Radio
                                    color="primary"
                                    value={opt.value}
                                    checked={String(selectedValue) === String(opt.value)}
                                    id={ariaLabelledby}
                                />
                            }
                            label={opt.label}
                            {...others}
                        />
                    );
                })}
            </RadioGroup>
        </FormControl>
    );
};




export default AiRadio;