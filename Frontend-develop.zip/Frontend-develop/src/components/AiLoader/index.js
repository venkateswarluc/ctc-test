import React, { Fragment } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import LinearProgress from '@material-ui/core/LinearProgress';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        '& > * + *': {
            marginTop: theme.spacing(2),
        },
    },
}));


const AiLoader = ({ opened = false, ...props }) => {
    const classes = useStyles();


    return (
        <Fragment>
            {
                opened
                    ?
                    <div className={classes.root} style={{ color: "#127598" }}>
                        <LinearProgress  {...props} />
                    </div>
                    :
                    null
            }
        </Fragment>
    );
};



export default AiLoader;
