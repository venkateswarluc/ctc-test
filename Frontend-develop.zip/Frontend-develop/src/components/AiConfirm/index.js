import React from "react";

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';


const AiConfirm = (props) => {
    const {
        opened = false,
        title = "Confirm",
        message = "Are you sure?",
        yes = "Proceed",
        no = "Cancel",
        onDone
    } = props;

    const handleClose = isOk => () => {
        onDone(isOk);
    };

    return (
        <Dialog
            open={opened}
            onClose={handleClose(false)}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
        >
            <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
            <DialogContent style={{ maxWidth: 400, width: 280 }}>
                <DialogContentText id="alert-dialog-description">{message}</DialogContentText>
            </DialogContent>
            <DialogActions>
                <Button color="secondary" onClick={handleClose(false)}>{no}</Button>
                <Button onClick={handleClose(true)} color="primary" autoFocus>{yes}</Button>
            </DialogActions>
        </Dialog>
    );
}


export default AiConfirm;