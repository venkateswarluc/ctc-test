const path = require('path');
const HtmlWebpackPlugin = require("html-webpack-plugin");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const webpack = require('webpack');

const DEV_BACKEND_URL = '"https://dev.noola.com"';
const STAG_BACKEND_URL = '"https://noola-staging.noola.com"';
const PROD_BACKEND_URL = '"https://dev.noola.com"';

const URLS = {
  staging: STAG_BACKEND_URL,
  development: DEV_BACKEND_URL,
  production: PROD_BACKEND_URL
}

module.exports = (env, argv) => {
  const isProd = env.TARGET_ENV  === "production";
  const config = {};
  config.mode = env.TARGET_ENV;

  config.devtool = isProd ? false : "eval";

  config.entry = './src/index.js';
  config.output = {
    path: path.resolve(__dirname, 'dist'),
    filename: isProd ? "bundle.[hash].min.js" : "bundle.js",
  };

  config.resolve = {
    alias: {
      appRoot: path.join(__dirname, "/src")
    },
    extensions: ['*', '.mjs', '.js', '.jsx']
  };


  config.module = {
    rules: [
      {
        test: /\.(mjs|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader'
        },
      }, {
        test: /\.(png|jpe?g|gif)$/i,
        loader: 'file-loader',
        options: {
          outputPath: "images/",
          publicPath: "/images/"
        },
      }
    ]
  };

  config.plugins = [];

  config.plugins.push(
    new CleanWebpackPlugin(),
    new HtmlWebpackPlugin({
      template: path.join(__dirname, "/HTML_TEMPLATE/index.html"),
      minify: {
        collapseWhitespace: isProd,
        minifyCSS: isProd
      }
    }),
    new webpack.DefinePlugin({
      'process.env': {
        'BACKEND_URL': URLS[env.TARGET_ENV]
      }
    }),
    new CopyWebpackPlugin(
      [{
        from: path.join(__dirname, "/HTML_TEMPLATE")
      }],
      {
        ignore: ["*.html", "service-worker.js"]
      }
    ),
  );


  config.devServer = {
    port: 3005,
    stats: "minimal",
    proxy: {
      '/api': {
        target: 'https://noola-927083833.us-east-1.elb.amazonaws.com',        
        secure: false
      }
    }
  };


  return config;
};